import mongoose, { Document, Schema } from 'mongoose';

export interface IQuestion extends Document {
  category: string;
  question: string;
  options: string[];
  correct: number;
  difficulty: 'easy' | 'medium' | 'hard';
  explanation: string;
  tags: string[];
}

const QuestionSchema = new Schema<IQuestion>(
  {
    category: { type: String, required: true },
    question: { type: String, required: true },
    options: { type: [String], required: true, validate: (v: string[]) => v.length === 4 },
    correct: { type: Number, required: true, min: 0, max: 3 },
    difficulty: { type: String, enum: ['easy', 'medium', 'hard'], required: true },
    explanation: { type: String, default: '' },
    tags: { type: [String], default: [] },
  },
  { timestamps: true }
);

export default mongoose.model<IQuestion>('Question', QuestionSchema);
