import mongoose, { Document, Schema } from 'mongoose';

export interface ITestSession extends Document {
  userId: string;
  domain: string;
  selectedSkills: string[];
  selectedRole: string;
  weakAreas: string[];
  questionIds: string[];
  status: 'active' | 'completed';
  createdAt: Date;
}

const TestSessionSchema = new Schema<ITestSession>(
  {
    userId: { type: String, required: true },
    domain: { type: String, default: 'engineering' },
    selectedSkills: { type: [String], default: [] },
    selectedRole: { type: String, default: '' },
    weakAreas: { type: [String], default: [] },
    questionIds: { type: [String], default: [] },
    status: { type: String, enum: ['active', 'completed'], default: 'active' },
  },
  { timestamps: true }
);

export default mongoose.model<ITestSession>('TestSession', TestSessionSchema);
