import mongoose, { Document, Schema } from 'mongoose';

export interface ITranscriptEntry {
  timestamp: string;
  speaker: 'ai' | 'user';
  text: string;
}

export interface IInterview extends Document {
  userId: string;
  question: string;
  transcript: ITranscriptEntry[];
  audioUrl?: string;
  aiEvaluation?: {
    problemSolving: number;
    communication: number;
    domainExpertise: number;
    overallScore: number;
    feedback: string;
  };
  humanReview?: {
    requested: boolean;
    reviewerName?: string;
    strengths?: string;
    areasForGrowth?: string;
    completedAt?: Date;
  };
  status: 'in_progress' | 'ai_complete' | 'human_reviewed';
  completedAt?: Date;
}

const TranscriptEntrySchema = new Schema<ITranscriptEntry>({
  timestamp: { type: String, required: true },
  speaker: { type: String, enum: ['ai', 'user'], required: true },
  text: { type: String, required: true },
});

const InterviewSchema = new Schema<IInterview>(
  {
    userId: { type: String, required: true },
    question: { type: String, required: true },
    transcript: { type: [TranscriptEntrySchema], default: [] },
    audioUrl: { type: String, default: null },
    aiEvaluation: {
      problemSolving: Number,
      communication: Number,
      domainExpertise: Number,
      overallScore: Number,
      feedback: String,
    },
    humanReview: {
      requested: { type: Boolean, default: false },
      reviewerName: String,
      strengths: String,
      areasForGrowth: String,
      completedAt: Date,
    },
    status: {
      type: String,
      enum: ['in_progress', 'ai_complete', 'human_reviewed'],
      default: 'in_progress',
    },
    completedAt: { type: Date, default: null },
  },
  { timestamps: true }
);

export default mongoose.model<IInterview>('Interview', InterviewSchema);
