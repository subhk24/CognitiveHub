import mongoose, { Document, Schema } from 'mongoose';

export interface IAnswer {
  questionId: string;
  selected: number;
  correct: number;
  confidence: number;
  timeSpent?: number;
}

export interface ITestResult extends Document {
  userId: string;
  score: number;
  answers: IAnswer[];
  totalQuestions: number;
  correctAnswers: number;
  avgConfidence: number;
  completedAt: Date;
  difficulty: string;
}

const AnswerSchema = new Schema<IAnswer>({
  questionId: { type: String, required: true },
  selected: { type: Number, required: true },
  correct: { type: Number, required: true },
  confidence: { type: Number, required: true },
  timeSpent: { type: Number, default: 0 },
});

const TestResultSchema = new Schema<ITestResult>(
  {
    userId: { type: String, required: true },
    score: { type: Number, required: true },
    answers: { type: [AnswerSchema], default: [] },
    totalQuestions: { type: Number, required: true },
    correctAnswers: { type: Number, required: true },
    avgConfidence: { type: Number, required: true },
    completedAt: { type: Date, default: Date.now },
    difficulty: { type: String, default: 'mixed' },
  },
  { timestamps: true }
);

export default mongoose.model<ITestResult>('TestResult', TestResultSchema);
