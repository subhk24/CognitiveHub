import mongoose, { Document, Schema } from 'mongoose';

export interface ICommunityMessage extends Document {
  userId: string;
  username: string;
  avatar: string;
  message: string;
  topic: string;
  likes: number;
  createdAt: Date;
}

const CommunityMessageSchema = new Schema<ICommunityMessage>(
  {
    userId: { type: String, required: true },
    username: { type: String, required: true },
    avatar: { type: String, default: '⭐' },
    message: { type: String, required: true, maxlength: 2000 },
    topic: { type: String, default: 'General' },
    likes: { type: Number, default: 0 },
  },
  { timestamps: true }
);

export default mongoose.model<ICommunityMessage>('CommunityMessage', CommunityMessageSchema);
