import { Router, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import mongoose from 'mongoose';
import User from '../models/User';
import { memStore } from '../store/memoryStore';
import { authenticate, AuthRequest } from '../middleware/auth';

const router = Router();

const isDbConnected = () => mongoose.connection.readyState === 1;

const generateToken = (userId: string, email: string): string => {
  const secret = process.env.JWT_SECRET || 'fallback_secret';
  return jwt.sign({ userId, email }, secret, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  } as jwt.SignOptions);
};

const userToPublic = (user: { _id?: unknown; id?: string; name: string; email: string; score: number; xp: number; level: number; specialization?: string | null; skills: string[]; projects: string[] }) => ({
  id: user._id || user.id,
  name: user.name,
  email: user.email,
  score: user.score,
  xp: user.xp,
  level: user.level,
  specialization: user.specialization,
  skills: user.skills,
  projects: user.projects,
});

router.post('/register', async (req: Request, res: Response): Promise<void> => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
      res.status(400).json({ error: 'Name, email and password are required' });
      return;
    }

    if (isDbConnected()) {
      const existing = await User.findOne({ email });
      if (existing) { res.status(409).json({ error: 'Email already registered' }); return; }
      const user = await User.create({ name, email, password });
      const token = generateToken(String(user._id), user.email);
      res.status(201).json({ token, user: userToPublic(user) });
    } else {
      const existing = memStore.users.findByEmail(email);
      if (existing) { res.status(409).json({ error: 'Email already registered' }); return; }
      const user = await memStore.users.create({ name, email, password });
      const token = generateToken(user.id, user.email);
      res.status(201).json({ token, user: userToPublic(user) });
    }
  } catch (err: unknown) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Registration failed' });
  }
});

router.post('/login', async (req: Request, res: Response): Promise<void> => {
  try {
    const { email, password } = req.body;
    if (!email || !password) { res.status(400).json({ error: 'Email and password are required' }); return; }

    if (isDbConnected()) {
      const user = await User.findOne({ email });
      if (!user || !(await user.comparePassword(password))) {
        res.status(401).json({ error: 'Invalid credentials' }); return;
      }
      const token = generateToken(String(user._id), user.email);
      res.json({ token, user: userToPublic(user) });
    } else {
      const user = memStore.users.findByEmail(email);
      if (!user || !(await memStore.users.comparePassword(user, password))) {
        res.status(401).json({ error: 'Invalid credentials' }); return;
      }
      const token = generateToken(user.id, user.email);
      res.json({ token, user: userToPublic(user) });
    }
  } catch (err: unknown) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Login failed' });
  }
});

router.get('/me', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (isDbConnected()) {
      const user = await User.findById(req.userId).select('-password');
      if (!user) { res.status(404).json({ error: 'User not found' }); return; }
      res.json({ user: userToPublic(user) });
    } else {
      const user = memStore.users.findById(req.userId || '');
      if (!user) { res.status(404).json({ error: 'User not found' }); return; }
      res.json({ user: userToPublic(user) });
    }
  } catch (err: unknown) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to fetch user' });
  }
});

router.put('/profile', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { name, specialization, skills, projects } = req.body;
    const update: Record<string, unknown> = {};
    if (name) update.name = name;
    if (specialization !== undefined) update.specialization = specialization;
    if (skills) update.skills = skills;
    if (projects) update.projects = projects;

    if (isDbConnected()) {
      const user = await User.findByIdAndUpdate(req.userId, update, { new: true }).select('-password');
      if (!user) { res.status(404).json({ error: 'User not found' }); return; }
      res.json({ user: userToPublic(user) });
    } else {
      const user = memStore.users.update(req.userId || '', update as never);
      if (!user) { res.status(404).json({ error: 'User not found' }); return; }
      res.json({ user: userToPublic(user) });
    }
  } catch (err: unknown) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Profile update failed' });
  }
});

export default router;
