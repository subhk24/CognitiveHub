import { Router, Request, Response } from 'express';

const router = Router();

const SKILL_KEYWORDS: Record<string, string[]> = {
  React: ['react', 'reactjs', 'react.js', 'jsx', 'tsx', 'hooks', 'useState', 'useEffect', 'redux', 'react-router'],
  'Node.js': ['node', 'nodejs', 'node.js', 'express', 'expressjs', 'koa', 'fastify', 'nest', 'nestjs'],
  TypeScript: ['typescript', 'ts', 'tsx', 'typed javascript', 'type-safe'],
  Python: ['python', 'django', 'flask', 'fastapi', 'pandas', 'numpy', 'scikit', 'pytorch', 'tensorflow', 'keras'],
  MongoDB: ['mongodb', 'mongo', 'mongoose', 'atlas', 'nosql', 'document database'],
  PostgreSQL: ['postgresql', 'postgres', 'sql', 'relational database', 'sequelize', 'prisma', 'typeorm'],
  'Machine Learning': ['machine learning', 'ml', 'model training', 'neural network', 'deep learning', 'gradient', 'training data', 'classification', 'regression', 'clustering'],
  'Large Language Models': ['llm', 'gpt', 'openai', 'langchain', 'prompt engineering', 'fine-tuning', 'rag', 'retrieval augmented', 'embeddings', 'vector database', 'anthropic', 'claude', 'gemini'],
  'Computer Vision': ['computer vision', 'image recognition', 'object detection', 'opencv', 'yolo', 'cnn', 'convolutional'],
  Docker: ['docker', 'container', 'kubernetes', 'k8s', 'devops', 'ci/cd', 'pipeline'],
  AWS: ['aws', 'amazon web services', 's3', 'ec2', 'lambda', 'cloud', 'gcp', 'azure'],
  JWT: ['jwt', 'json web token', 'authentication', 'auth', 'oauth', 'session', 'authorization'],
  GraphQL: ['graphql', 'apollo', 'query language', 'schema', 'resolver'],
  Redis: ['redis', 'caching', 'cache', 'in-memory store', 'pub/sub'],
  Java: ['java', 'spring', 'spring boot', 'maven', 'gradle', 'jvm', 'kotlin'],
  DSA: ['data structures', 'algorithms', 'arrays', 'linked list', 'binary tree', 'graph', 'dynamic programming', 'recursion', 'sorting'],
};

const TOPIC_MAP: Record<string, string[]> = {
  React: ['React hooks', 'State management', 'Component lifecycle', 'React performance', 'Context API'],
  'Node.js': ['Express middleware', 'REST API design', 'Authentication', 'Error handling', 'Async/await'],
  TypeScript: ['Type inference', 'Generics', 'Interfaces vs types', 'Decorators', 'Type guards'],
  Python: ['List comprehensions', 'Decorators', 'Async programming', 'Testing', 'Package management'],
  MongoDB: ['Schema design', 'Aggregation pipeline', 'Indexing', 'Transactions', 'Atlas search'],
  PostgreSQL: ['Query optimization', 'Joins', 'Indexes', 'Transactions', 'Stored procedures'],
  'Machine Learning': ['Model evaluation', 'Overfitting', 'Feature engineering', 'Cross-validation', 'Hyperparameter tuning'],
  'Large Language Models': ['Prompt design', 'RAG architecture', 'Fine-tuning strategies', 'Hallucination reduction', 'Token efficiency'],
  JWT: ['Token refresh', 'Secure storage', 'Role-based access', 'OAuth flows', 'Session management'],
  Docker: ['Dockerfile optimization', 'Compose', 'Networking', 'Volume management', 'CI/CD integration'],
  Java: ['OOP principles', 'Collections', 'Concurrency', 'Spring Boot', 'JPA/Hibernate'],
  DSA: ['Time complexity', 'Space complexity', 'Recursion', 'Dynamic programming', 'Graph traversal'],
};

const WEAK_AREA_MAP: Record<string, string[]> = {
  React: ['State management complexity', 'Performance optimization', 'Testing components'],
  'Node.js': ['Async error handling', 'Scalability patterns', 'Security best practices'],
  'Machine Learning': ['Model selection', 'Data preprocessing', 'Evaluation metrics'],
  'Large Language Models': ['Prompt reliability', 'Cost optimization', 'Evaluation'],
  MongoDB: ['Schema design for scale', 'Aggregation complexity', 'Data consistency'],
  Java: ['Concurrency issues', 'Memory management', 'Design patterns'],
  DSA: ['Dynamic programming', 'Graph algorithms', 'Time complexity analysis'],
};

router.post('/analyze', async (req: Request, res: Response): Promise<void> => {
  try {
    const { projectDescription } = req.body;
    if (!projectDescription || typeof projectDescription !== 'string') {
      res.status(400).json({ error: 'projectDescription is required' });
      return;
    }

    const text = projectDescription.toLowerCase();
    const detectedSkills: string[] = [];
    const suggestedTopics: string[] = [];
    const suggestedWeakAreas: string[] = [];

    for (const [skill, keywords] of Object.entries(SKILL_KEYWORDS)) {
      if (keywords.some((kw) => text.includes(kw.toLowerCase()))) {
        detectedSkills.push(skill);
        const topics = TOPIC_MAP[skill];
        if (topics) suggestedTopics.push(...topics.slice(0, 2));
        const weakAreas = WEAK_AREA_MAP[skill];
        if (weakAreas) suggestedWeakAreas.push(weakAreas[0]);
      }
    }

    const uniqueTopics = [...new Set(suggestedTopics)].slice(0, 8);
    const uniqueWeak = [...new Set(suggestedWeakAreas)].slice(0, 4);

    if (detectedSkills.length === 0) {
      res.json({
        detectedSkills: [],
        suggestedTopics: ['AI Fundamentals', 'Prompt Engineering', 'Machine Learning Basics'],
        suggestedWeakAreas: ['Core concepts', 'Applied AI'],
      });
      return;
    }

    res.json({
      detectedSkills,
      suggestedTopics: uniqueTopics,
      suggestedWeakAreas: uniqueWeak,
    });
  } catch (err: unknown) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Analysis failed' });
  }
});

export default router;
