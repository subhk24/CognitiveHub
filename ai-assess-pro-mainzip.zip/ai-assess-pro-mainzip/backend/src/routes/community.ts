import { Router, Response } from 'express';
import mongoose from 'mongoose';
import CommunityMessage from '../models/CommunityMessage';
import { memStore } from '../store/memoryStore';
import { authenticate, AuthRequest } from '../middleware/auth';
import { getIo } from '../socket';

const router = Router();
const isDbConnected = () => mongoose.connection.readyState === 1;

router.get('/messages', async (req, res: Response): Promise<void> => {
  try {
    const { topic, limit = '50' } = req.query;
    if (isDbConnected()) {
      const filter: Record<string, unknown> = {};
      if (topic && topic !== 'All') filter.topic = topic;
      const messages = await CommunityMessage.find(filter)
        .sort({ createdAt: -1 })
        .limit(Number(limit));
      res.json({ messages: messages.reverse() });
    } else {
      const messages = memStore.community.list(topic as string | undefined, Number(limit));
      res.json({ messages });
    }
  } catch (err: unknown) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to fetch messages' });
  }
});

router.post('/messages', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { message, topic = 'General', avatar = '⭐' } = req.body;
    if (!message || !message.trim()) {
      res.status(400).json({ error: 'Message is required' });
      return;
    }

    const username = memStore.users.findById(req.userId || '')?.name || 'Anonymous';

    let saved: object;

    if (isDbConnected()) {
      const doc = await CommunityMessage.create({
        userId: req.userId,
        username,
        avatar,
        message: message.trim(),
        topic,
        likes: 0,
      });
      saved = {
        id: String(doc._id),
        userId: doc.userId,
        username: doc.username,
        avatar: doc.avatar,
        message: doc.message,
        topic: doc.topic,
        likes: doc.likes,
        createdAt: doc.createdAt,
      };
    } else {
      saved = memStore.community.create({
        userId: req.userId || '',
        username,
        avatar,
        message: message.trim(),
        topic,
      });
    }

    const io = getIo();
    if (io) {
      io.emit('newCommunityMessage', saved);
    }

    res.status(201).json({ message: saved });
  } catch (err: unknown) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to save message' });
  }
});

router.post('/messages/:id/like', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (isDbConnected()) {
      await CommunityMessage.findByIdAndUpdate(req.params.id, { $inc: { likes: 1 } });
    } else {
      memStore.community.like(req.params.id);
    }
    res.json({ success: true });
  } catch (err: unknown) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to like message' });
  }
});

export default router;
