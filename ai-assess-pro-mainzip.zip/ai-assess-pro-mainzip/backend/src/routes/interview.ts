import { Router, Response } from 'express';
import mongoose from 'mongoose';
import Interview from '../models/Interview';
import { memStore } from '../store/memoryStore';
import { authenticate, AuthRequest } from '../middleware/auth';

const router = Router();
const isDbConnected = () => mongoose.connection.readyState === 1;

const aiQuestions = [
  'How would you architect a decentralized cognitive node that maintains data integrity during a high-latency network partition?',
  'Explain how you would implement a real-time bias detection system for a large language model in production.',
  'Describe your approach to designing a multi-agent system where agents must coordinate to solve complex analytical tasks.',
  'How would you optimize a RAG pipeline for domain-specific knowledge retrieval with low latency requirements?',
  'Walk me through how you would evaluate and mitigate hallucination risks in a customer-facing AI product.',
];

const getTimestamp = () =>
  new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' });

router.post('/start', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const question = aiQuestions[Math.floor(Math.random() * aiQuestions.length)];
    const firstEntry = { timestamp: getTimestamp(), speaker: 'ai' as const, text: question };

    if (isDbConnected()) {
      const interview = await Interview.create({
        userId: req.userId,
        question,
        transcript: [firstEntry],
        status: 'in_progress',
      });
      res.status(201).json({ interview });
    } else {
      const interview = memStore.interviews.create({
        userId: req.userId || '',
        question,
        transcript: [firstEntry],
        status: 'in_progress',
      });
      res.status(201).json({ interview: { ...interview, _id: interview.id } });
    }
  } catch (err: unknown) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to start interview' });
  }
});

router.post('/:id/transcript', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { text, speaker = 'user' } = req.body;
    if (!text) { res.status(400).json({ error: 'Transcript text is required' }); return; }

    const entry = { timestamp: getTimestamp(), speaker: speaker as 'ai' | 'user', text };

    if (isDbConnected()) {
      const interview = await Interview.findOneAndUpdate(
        { _id: req.params.id, userId: req.userId },
        { $push: { transcript: entry } },
        { new: true }
      );
      if (!interview) { res.status(404).json({ error: 'Interview not found' }); return; }
      res.json({ entry, interview });
    } else {
      const interview = memStore.interviews.findById(req.params.id);
      if (!interview) { res.status(404).json({ error: 'Interview not found' }); return; }
      const updated = memStore.interviews.update(req.params.id, {
        transcript: [...(interview.transcript as typeof entry[]), entry],
      });
      res.json({ entry, interview: { ...updated, _id: updated?.id } });
    }
  } catch (err: unknown) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to save transcript' });
  }
});

router.post('/:id/complete', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const aiEvaluation = {
      problemSolving: Math.round(65 + Math.random() * 30),
      communication: Math.round(60 + Math.random() * 35),
      domainExpertise: Math.round(55 + Math.random() * 40),
      overallScore: 0,
      feedback: 'Strong architectural thinking. Excellent understanding of distributed systems.',
    };
    aiEvaluation.overallScore = Math.round(
      (aiEvaluation.problemSolving + aiEvaluation.communication + aiEvaluation.domainExpertise) / 3
    );

    if (isDbConnected()) {
      const interview = await Interview.findOneAndUpdate(
        { _id: req.params.id, userId: req.userId },
        { aiEvaluation, status: 'ai_complete', completedAt: new Date() },
        { new: true }
      );
      if (!interview) { res.status(404).json({ error: 'Interview not found' }); return; }
      res.json({ interview, aiEvaluation });
    } else {
      const updated = memStore.interviews.update(req.params.id, {
        aiEvaluation,
        status: 'ai_complete',
        completedAt: new Date(),
      });
      res.json({ interview: { ...updated, _id: updated?.id }, aiEvaluation });
    }
  } catch (err: unknown) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to complete interview' });
  }
});

router.post('/:id/human-review', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const humanReview = {
      requested: true,
      reviewerName: 'Dr. Sarah Chen',
      strengths: 'Strong architectural thinking. Excellent understanding of distributed systems and consensus mechanisms.',
      areasForGrowth: 'Could elaborate more on edge-case handling for network partitions. Consider CAP theorem implications.',
      completedAt: new Date(),
    };

    if (isDbConnected()) {
      const interview = await Interview.findOneAndUpdate(
        { _id: req.params.id, userId: req.userId },
        { humanReview, status: 'human_reviewed' },
        { new: true }
      );
      if (!interview) { res.status(404).json({ error: 'Interview not found' }); return; }
      res.json({ interview, humanReview });
    } else {
      const updated = memStore.interviews.update(req.params.id, { humanReview, status: 'human_reviewed' });
      res.json({ interview: { ...updated, _id: updated?.id }, humanReview });
    }
  } catch (err: unknown) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to request human review' });
  }
});

router.get('/history', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (isDbConnected()) {
      const interviews = await Interview.find({ userId: req.userId }).sort({ createdAt: -1 }).limit(10);
      res.json({ interviews });
    } else {
      const interviews = memStore.interviews.findByUser(req.userId || '').map((i) => ({ ...i, _id: i.id }));
      res.json({ interviews });
    }
  } catch (err: unknown) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to fetch interview history' });
  }
});

export default router;
