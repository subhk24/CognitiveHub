import { Router, Response } from 'express';
import mongoose from 'mongoose';
import TestResult from '../models/TestResult';
import User from '../models/User';
import { memStore } from '../store/memoryStore';
import { authenticate, AuthRequest } from '../middleware/auth';
import { getIo } from '../socket';

const router = Router();
const isDbConnected = () => mongoose.connection.readyState === 1;

const emitLeaderboardUpdate = async () => {
  const io = getIo();
  if (!io) return;
  try {
    let leaderboard;
    if (isDbConnected()) {
      leaderboard = await User.find().select('name score xp level specialization').sort({ score: -1 }).limit(20);
    } else {
      leaderboard = memStore.users.list().sort((a, b) => b.score - a.score).slice(0, 20).map((u) => ({
        _id: u.id,
        name: u.name,
        score: u.score,
        xp: u.xp,
        level: u.level,
        specialization: u.specialization,
      }));
    }
    io.emit('leaderboardUpdated', { leaderboard });
  } catch {}
};

router.post('/submit', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { answers, totalQuestions } = req.body;
    if (!answers || !Array.isArray(answers)) {
      res.status(400).json({ error: 'Answers array is required' });
      return;
    }

    const correctAnswers = answers.filter(
      (a: { selected: number; correct: number }) => a.selected === a.correct
    ).length;
    const avgConfidence = answers.reduce((acc: number, a: { confidence: number }) => acc + a.confidence, 0) / answers.length;
    const score = Math.round((correctAnswers / (totalQuestions || answers.length)) * 70 + (avgConfidence / 100) * 30);

    if (isDbConnected()) {
      const result = await TestResult.create({
        userId: req.userId,
        score,
        answers: answers.map((a: { questionId?: string; selected: number; correct: number; confidence: number; timeSpent?: number }, i: number) => ({
          questionId: a.questionId || String(i),
          selected: a.selected,
          correct: a.correct,
          confidence: a.confidence,
          timeSpent: a.timeSpent || 0,
        })),
        totalQuestions: totalQuestions || answers.length,
        correctAnswers,
        avgConfidence,
        completedAt: new Date(),
      });
      await User.findByIdAndUpdate(req.userId, { $set: { score }, $inc: { xp: Math.round(score * 10) } });
      await emitLeaderboardUpdate();
      res.status(201).json({ result: { id: result._id, score, correctAnswers, totalQuestions: result.totalQuestions, avgConfidence, completedAt: result.completedAt } });
    } else {
      const result = memStore.testResults.create({
        userId: req.userId || '',
        score,
        answers,
        totalQuestions: totalQuestions || answers.length,
        correctAnswers,
        avgConfidence,
        completedAt: new Date(),
      });
      memStore.users.update(req.userId || '', { score, xp: score * 10 });
      await emitLeaderboardUpdate();
      res.status(201).json({ result: { id: result.id, score, correctAnswers, totalQuestions: result.totalQuestions, avgConfidence, completedAt: result.completedAt } });
    }
  } catch (err: unknown) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to submit test' });
  }
});

router.get('/history', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (isDbConnected()) {
      const results = await TestResult.find({ userId: req.userId }).sort({ completedAt: -1 }).limit(10);
      res.json({ results });
    } else {
      const results = memStore.testResults.findByUser(req.userId || '');
      res.json({ results });
    }
  } catch (err: unknown) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to fetch test history' });
  }
});

router.get('/leaderboard', async (_req, res: Response): Promise<void> => {
  try {
    if (isDbConnected()) {
      const users = await User.find().select('name score xp level specialization').sort({ score: -1 }).limit(20);
      res.json({ leaderboard: users });
    } else {
      const users = memStore.users.list().sort((a, b) => b.score - a.score).slice(0, 20).map((u) => ({
        _id: u.id,
        name: u.name,
        score: u.score,
        xp: u.xp,
        level: u.level,
        specialization: u.specialization,
      }));
      res.json({ leaderboard: users });
    }
  } catch (err: unknown) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to fetch leaderboard' });
  }
});

export default router;
