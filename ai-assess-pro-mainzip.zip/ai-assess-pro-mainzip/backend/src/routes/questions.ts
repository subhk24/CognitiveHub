import { Router, Response } from 'express';
import Question from '../models/Question';
import TestSession from '../models/TestSession';
import { authenticate, AuthRequest } from '../middleware/auth';

const router = Router();

const defaultQuestions = [
  {
    _id: 'q1',
    category: 'COMPLEX ANALYTICS',
    question: 'If the cognitive load of a neural subset increases by 14% every cycle, what is the asymptotic efficiency after n iterations?',
    options: ['Logarithmic divergence at n=10', 'Linear stabilization at cycle peak', 'Exponential decay of output parity', 'Recursive entropy amplification'],
    correct: 1,
    difficulty: 'hard',
    explanation: 'This tests iterative computational processes and asymptotic analysis in neural network contexts.',
    tags: ['analytics', 'neural-networks'],
  },
  {
    _id: 'q2',
    category: 'AI FUNDAMENTALS',
    question: 'Which technique is most effective for reducing hallucination in large language models?',
    options: ['Increasing temperature parameter', 'Retrieval-augmented generation (RAG)', 'Removing attention layers', 'Expanding context window only'],
    correct: 1,
    difficulty: 'medium',
    explanation: 'RAG grounds outputs in retrieved factual documents.',
    tags: ['llm', 'rag'],
  },
  {
    _id: 'q3',
    category: 'PROMPT ENGINEERING',
    question: 'What is the primary benefit of chain-of-thought prompting?',
    options: ['Reduces token usage significantly', 'Improves reasoning by breaking down steps', 'Eliminates need for fine-tuning', 'Increases model training speed'],
    correct: 1,
    difficulty: 'medium',
    explanation: 'Chain-of-thought guides step-by-step reasoning.',
    tags: ['prompting'],
  },
  {
    _id: 'q4',
    category: 'NEURAL ARCHITECTURE',
    question: 'In transformer models, what does the attention mechanism primarily compute?',
    options: ['Gradient descent optimization', 'Weighted relevance between tokens', 'Backpropagation error signals', 'Loss function minimization'],
    correct: 1,
    difficulty: 'hard',
    explanation: 'Attention computes a weighted sum based on query-key similarity.',
    tags: ['transformers', 'attention'],
  },
  {
    _id: 'q5',
    category: 'AI ETHICS',
    question: 'Which approach best addresses bias in AI training data?',
    options: ['Using larger datasets only', 'Diverse data sourcing and regular audits', 'Removing all demographic data', 'Increasing model parameters'],
    correct: 1,
    difficulty: 'medium',
    explanation: 'Diverse sourcing with audits is most comprehensive.',
    tags: ['ethics', 'bias'],
  },
  {
    _id: 'q6',
    category: 'MACHINE LEARNING',
    question: 'What is the vanishing gradient problem most associated with?',
    options: ['Convolutional neural networks', 'Deep recurrent neural networks', 'Decision tree ensembles', 'Linear regression models'],
    correct: 1,
    difficulty: 'hard',
    explanation: 'Deep RNNs suffer most from vanishing gradients.',
    tags: ['training', 'rnn'],
  },
  {
    _id: 'q7',
    category: 'AI TOOLS',
    question: "Which metric best evaluates a generative model's output quality?",
    options: ['Mean squared error only', 'Human evaluation combined with automated metrics', 'Training loss convergence', 'Parameter count comparison'],
    correct: 1,
    difficulty: 'medium',
    explanation: 'Human + automated metrics give the best assessment.',
    tags: ['evaluation', 'generative'],
  },
  {
    _id: 'q8',
    category: 'REACT',
    question: 'Which React hook should you use to avoid re-creating expensive functions on every render?',
    options: ['useState', 'useCallback', 'useRef', 'useContext'],
    correct: 1,
    difficulty: 'medium',
    explanation: 'useCallback memoizes functions so they are not recreated unless dependencies change.',
    tags: ['react', 'hooks', 'performance'],
  },
  {
    _id: 'q9',
    category: 'NODE.JS',
    question: 'In Express, which middleware correctly handles async errors?',
    options: [
      'app.use((err, req, res, next) => res.status(500).json({ error: err.message }))',
      'app.use(async (req, res) => {})',
      'process.on("uncaughtException")',
      'try/catch inside each route handler only',
    ],
    correct: 0,
    difficulty: 'medium',
    explanation: 'Express error middleware requires 4 arguments: err, req, res, next.',
    tags: ['nodejs', 'express', 'error-handling'],
  },
  {
    _id: 'q10',
    category: 'MONGODB',
    question: 'Which MongoDB aggregation stage filters documents based on field values?',
    options: ['$group', '$match', '$project', '$lookup'],
    correct: 1,
    difficulty: 'easy',
    explanation: '$match filters documents like a WHERE clause in SQL.',
    tags: ['mongodb', 'aggregation'],
  },
  {
    _id: 'q11',
    category: 'STATE MANAGEMENT',
    question: 'In Redux, what is the correct way to handle an async API call?',
    options: [
      'Directly in the reducer',
      'Using a thunk or middleware like redux-saga',
      'In the component useEffect only',
      'Using localStorage as a bridge',
    ],
    correct: 1,
    difficulty: 'medium',
    explanation: 'Thunks or sagas separate side effects from pure reducer logic.',
    tags: ['redux', 'state-management', 'react'],
  },
  {
    _id: 'q12',
    category: 'DSA',
    question: 'What is the time complexity of binary search on a sorted array?',
    options: ['O(n)', 'O(log n)', 'O(n log n)', 'O(1)'],
    correct: 1,
    difficulty: 'easy',
    explanation: 'Binary search halves the search space each iteration, giving O(log n).',
    tags: ['dsa', 'searching', 'algorithms'],
  },
  {
    _id: 'q13',
    category: 'JAVA',
    question: 'Which Java collection maintains insertion order and allows duplicate elements?',
    options: ['HashSet', 'TreeSet', 'ArrayList', 'HashMap'],
    correct: 2,
    difficulty: 'easy',
    explanation: 'ArrayList is an ordered, index-based collection that allows duplicates.',
    tags: ['java', 'collections'],
  },
  {
    _id: 'q14',
    category: 'AUTH',
    question: 'Where should a JWT refresh token be stored securely in a browser?',
    options: ['localStorage', 'sessionStorage', 'An HttpOnly cookie', 'Redux store'],
    correct: 2,
    difficulty: 'hard',
    explanation: 'HttpOnly cookies cannot be accessed by JavaScript, preventing XSS attacks.',
    tags: ['jwt', 'auth', 'security'],
  },
];

const SKILL_TAG_MAP: Record<string, string[]> = {
  react: ['react', 'hooks', 'state-management', 'performance', 'jsx'],
  'react.js': ['react', 'hooks', 'state-management'],
  'node.js': ['nodejs', 'express', 'error-handling', 'api'],
  nodejs: ['nodejs', 'express', 'error-handling', 'api'],
  express: ['nodejs', 'express', 'error-handling'],
  mongodb: ['mongodb', 'aggregation', 'nosql'],
  mongoose: ['mongodb', 'aggregation'],
  typescript: ['typescript', 'generics', 'types'],
  python: ['python', 'pandas', 'numpy'],
  jwt: ['jwt', 'auth', 'security'],
  authentication: ['jwt', 'auth', 'security'],
  redux: ['redux', 'state-management', 'react'],
  java: ['java', 'collections', 'oop'],
  dsa: ['dsa', 'searching', 'algorithms', 'recursion'],
  'data structures': ['dsa', 'searching', 'algorithms'],
  algorithms: ['dsa', 'searching', 'algorithms'],
  'machine learning': ['training', 'rnn', 'evaluation', 'generative'],
  ml: ['training', 'rnn', 'evaluation'],
  llm: ['llm', 'rag', 'prompting', 'attention'],
  'prompt engineering': ['prompting', 'llm'],
  rag: ['llm', 'rag'],
  ai: ['llm', 'rag', 'prompting', 'ethics', 'bias', 'transformers', 'attention'],
};

function getTagsForSkills(skills: string[], weakAreas: string[]): string[] {
  const tags = new Set<string>();
  for (const skill of skills) {
    const normalized = skill.toLowerCase();
    for (const [key, vals] of Object.entries(SKILL_TAG_MAP)) {
      if (normalized.includes(key) || key.includes(normalized)) {
        vals.forEach((t) => tags.add(t));
      }
    }
  }
  for (const area of weakAreas) {
    const normalized = area.toLowerCase();
    for (const [key, vals] of Object.entries(SKILL_TAG_MAP)) {
      if (normalized.includes(key) || key.includes(normalized)) {
        vals.forEach((t) => tags.add(t));
      }
    }
  }
  return [...tags];
}

router.post('/start-test', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const {
      domain = 'engineering',
      selectedSkills = [],
      selectedRole = '',
      weakAreas = [],
    } = req.body;

    const targetTags = getTagsForSkills(selectedSkills, weakAreas);

    let questions = defaultQuestions;

    if (targetTags.length > 0) {
      const matched = defaultQuestions.filter((q) =>
        q.tags.some((tag) => targetTags.includes(tag))
      );
      const unmatched = defaultQuestions.filter((q) =>
        !q.tags.some((tag) => targetTags.includes(tag))
      );
      questions = [...matched, ...unmatched].slice(0, 7);
    } else {
      questions = defaultQuestions.slice(0, 7);
    }

    const session = {
      id: `session_${Date.now()}`,
      domain,
      selectedSkills,
      selectedRole,
      weakAreas,
      questionIds: questions.map((q) => q._id),
    };

    const mongoose = await import('mongoose');
    const isDbConn = mongoose.default.connection.readyState === 1;
    if (isDbConn) {
      await TestSession.create({
        userId: req.userId,
        domain,
        selectedSkills,
        selectedRole,
        weakAreas,
        questionIds: questions.map((q) => q._id),
      });
    }

    res.json({ session, questions });
  } catch (err: unknown) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to start test' });
  }
});

router.get('/', authenticate, async (_req: AuthRequest, res: Response): Promise<void> => {
  try {
    const mongoose = await import('mongoose');
    if (mongoose.default.connection.readyState === 1) {
      const questions = await Question.find().limit(7);
      if (questions.length > 0) {
        res.json({ questions });
        return;
      }
    }
    res.json({ questions: defaultQuestions.slice(0, 7) });
  } catch (err: unknown) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to fetch questions' });
  }
});

router.get('/generate', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { specialization = 'engineering', count = '5' } = req.query;
    const categoryMap: Record<string, string[]> = {
      engineering: ['NEURAL ARCHITECTURE', 'MACHINE LEARNING', 'AI FUNDAMENTALS', 'COMPLEX ANALYTICS', 'REACT', 'NODE.JS', 'MONGODB'],
      design: ['AI TOOLS', 'PROMPT ENGINEERING', 'AI ETHICS', 'REACT'],
      mba: ['AI ETHICS', 'AI FUNDAMENTALS', 'AI TOOLS'],
      healthcare: ['AI ETHICS', 'AI FUNDAMENTALS', 'MACHINE LEARNING'],
    };
    const categories = categoryMap[String(specialization)] || categoryMap.engineering;
    const filtered = defaultQuestions.filter((q) => categories.includes(q.category));
    res.json({ questions: filtered.slice(0, Number(count)) });
  } catch (err: unknown) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to generate questions' });
  }
});

router.post('/seed', async (_req, res: Response): Promise<void> => {
  res.json({ message: 'Questions seeded from built-in bank' });
});

export default router;
