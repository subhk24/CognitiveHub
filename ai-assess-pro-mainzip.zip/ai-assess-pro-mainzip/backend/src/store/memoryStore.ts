import bcrypt from 'bcryptjs';

interface MemUser {
  id: string;
  name: string;
  email: string;
  password: string;
  specialization?: string;
  skills: string[];
  projects: string[];
  score: number;
  xp: number;
  level: number;
  createdAt: Date;
}

interface MemTestResult {
  id: string;
  userId: string;
  score: number;
  answers: object[];
  totalQuestions: number;
  correctAnswers: number;
  avgConfidence: number;
  completedAt: Date;
}

interface MemInterview {
  id: string;
  userId: string;
  question: string;
  transcript: object[];
  aiEvaluation?: object;
  humanReview?: object;
  status: string;
  completedAt?: Date;
  createdAt: Date;
}

interface MemCommunityMessage {
  id: string;
  userId: string;
  username: string;
  avatar: string;
  message: string;
  topic: string;
  likes: number;
  createdAt: Date;
}

let users: MemUser[] = [];
let testResults: MemTestResult[] = [];
let interviews: MemInterview[] = [];
let communityMessages: MemCommunityMessage[] = [
  {
    id: 'seed1',
    userId: 'system',
    username: 'Aria Chen',
    avatar: '🧠',
    message: 'Just completed the adaptive test! The RAG question was really insightful. Anyone else noticed how much better LLMs perform with structured prompts?',
    topic: 'Prompt Engineering',
    likes: 12,
    createdAt: new Date(Date.now() - 1000 * 60 * 5),
  },
  {
    id: 'seed2',
    userId: 'system',
    username: 'Marcus O.',
    avatar: '⚡',
    message: 'Pro tip: When fine-tuning models, always reserve 20% of your domain-specific data for validation. Saved me countless hours debugging poor performance.',
    topic: 'ML Tips',
    likes: 28,
    createdAt: new Date(Date.now() - 1000 * 60 * 15),
  },
  {
    id: 'seed3',
    userId: 'system',
    username: 'Dr. Patel',
    avatar: '🏥',
    message: 'Healthcare AI discussion: The bias issue in medical imaging AI is still a major challenge. We need more diverse training datasets representing all demographics.',
    topic: 'AI Ethics',
    likes: 34,
    createdAt: new Date(Date.now() - 1000 * 60 * 30),
  },
];
let idCounter = 1;

const generateId = () => String(idCounter++);

export const memStore = {
  users: {
    findByEmail: (email: string) => users.find((u) => u.email === email.toLowerCase()),
    findById: (id: string) => users.find((u) => u.id === id),
    create: async (data: { name: string; email: string; password: string }) => {
      const salt = await bcrypt.genSalt(10);
      const hashed = await bcrypt.hash(data.password, salt);
      const user: MemUser = {
        id: generateId(),
        name: data.name,
        email: data.email.toLowerCase(),
        password: hashed,
        skills: [],
        projects: [],
        score: 0,
        xp: 0,
        level: 1,
        createdAt: new Date(),
      };
      users.push(user);
      return user;
    },
    comparePassword: async (user: MemUser, candidate: string) => bcrypt.compare(candidate, user.password),
    update: (id: string, data: Partial<MemUser>) => {
      const idx = users.findIndex((u) => u.id === id);
      if (idx === -1) return null;
      users[idx] = { ...users[idx], ...data };
      return users[idx];
    },
    list: () => users,
  },

  testResults: {
    create: (data: Omit<MemTestResult, 'id'>) => {
      const result = { id: generateId(), ...data };
      testResults.push(result);
      return result;
    },
    findByUser: (userId: string) =>
      testResults.filter((r) => r.userId === userId).sort((a, b) => b.completedAt.getTime() - a.completedAt.getTime()),
  },

  interviews: {
    create: (data: Omit<MemInterview, 'id' | 'createdAt'>) => {
      const interview = { id: generateId(), createdAt: new Date(), ...data };
      interviews.push(interview);
      return interview;
    },
    findById: (id: string) => interviews.find((i) => i.id === id),
    update: (id: string, data: Partial<MemInterview>) => {
      const idx = interviews.findIndex((i) => i.id === id);
      if (idx === -1) return null;
      interviews[idx] = { ...interviews[idx], ...data };
      return interviews[idx];
    },
    findByUser: (userId: string) =>
      interviews.filter((i) => i.userId === userId).sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime()),
  },

  community: {
    list: (topic?: string, limit = 50) => {
      let msgs = [...communityMessages];
      if (topic && topic !== 'All') msgs = msgs.filter((m) => m.topic === topic);
      return msgs.sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime()).slice(-limit);
    },
    create: (data: { userId: string; username: string; avatar: string; message: string; topic: string }) => {
      const msg: MemCommunityMessage = {
        id: generateId(),
        likes: 0,
        createdAt: new Date(),
        ...data,
      };
      communityMessages.push(msg);
      return msg;
    },
    like: (id: string) => {
      const msg = communityMessages.find((m) => m.id === id);
      if (msg) msg.likes += 1;
      return msg;
    },
  },
};
