const BASE_URL = '/api';

const getToken = (): string | null => localStorage.getItem('cognitiveHub_token');

const headers = (): Record<string, string> => {
  const token = getToken();
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
};

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    ...options,
    headers: { ...headers(), ...(options?.headers || {}) },
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data as T;
}

export const api = {
  auth: {
    register: (name: string, email: string, password: string) =>
      request<{ token: string; user: User }>('/auth/register', {
        method: 'POST',
        body: JSON.stringify({ name, email, password }),
      }),

    login: (email: string, password: string) =>
      request<{ token: string; user: User }>('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password }),
      }),

    me: () => request<{ user: User }>('/auth/me'),

    updateProfile: (data: Partial<User>) =>
      request<{ user: User }>('/auth/profile', {
        method: 'PUT',
        body: JSON.stringify(data),
      }),
  },

  questions: {
    list: (params?: { difficulty?: string; category?: string; limit?: number }) => {
      const qs = params ? '?' + new URLSearchParams(params as Record<string, string>).toString() : '';
      return request<{ questions: Question[] }>(`/questions${qs}`);
    },
    generate: (params?: { specialization?: string; difficulty?: string; count?: number }) => {
      const qs = params ? '?' + new URLSearchParams(params as Record<string, string>).toString() : '';
      return request<{ questions: Question[] }>(`/questions/generate${qs}`);
    },
    seed: () => request<{ message: string }>('/questions/seed', { method: 'POST' }),
  },

  test: {
    submit: (answers: Answer[], totalQuestions: number) =>
      request<{ result: TestResult }>('/test/submit', {
        method: 'POST',
        body: JSON.stringify({ answers, totalQuestions }),
      }),

    history: () => request<{ results: TestResult[] }>('/test/history'),
    leaderboard: () => request<{ leaderboard: LeaderboardEntry[] }>('/test/leaderboard'),
  },

  interview: {
    start: () => request<{ interview: Interview }>('/interview/start', { method: 'POST' }),

    saveTranscript: (id: string, text: string, speaker: 'ai' | 'user' = 'user') =>
      request<{ entry: TranscriptEntry; interview: Interview }>(`/interview/${id}/transcript`, {
        method: 'POST',
        body: JSON.stringify({ text, speaker }),
      }),

    complete: (id: string) =>
      request<{ interview: Interview; aiEvaluation: AIEvaluation }>(`/interview/${id}/complete`, {
        method: 'POST',
      }),

    requestHumanReview: (id: string) =>
      request<{ interview: Interview; humanReview: HumanReview }>(`/interview/${id}/human-review`, {
        method: 'POST',
      }),

    history: () => request<{ interviews: Interview[] }>('/interview/history'),
  },
};

export interface User {
  id: string;
  name: string;
  email: string;
  score: number;
  xp: number;
  level: number;
  specialization?: string;
  skills: string[];
  projects: string[];
}

export interface Question {
  _id?: string;
  category: string;
  question: string;
  options: string[];
  correct: number;
  difficulty: string;
  explanation: string;
  tags: string[];
}

export interface Answer {
  questionId?: string;
  selected: number;
  correct: number;
  confidence: number;
  timeSpent?: number;
}

export interface TestResult {
  id: string;
  score: number;
  correctAnswers: number;
  totalQuestions: number;
  avgConfidence: number;
  completedAt: string;
}

export interface LeaderboardEntry {
  _id: string;
  name: string;
  score: number;
  xp: number;
  level: number;
  specialization?: string;
}

export interface TranscriptEntry {
  timestamp: string;
  speaker: 'ai' | 'user';
  text: string;
}

export interface AIEvaluation {
  problemSolving: number;
  communication: number;
  domainExpertise: number;
  overallScore: number;
  feedback: string;
}

export interface HumanReview {
  requested: boolean;
  reviewerName?: string;
  strengths?: string;
  areasForGrowth?: string;
  completedAt?: string;
}

export interface Interview {
  _id: string;
  userId: string;
  question: string;
  transcript: TranscriptEntry[];
  aiEvaluation?: AIEvaluation;
  humanReview?: HumanReview;
  status: string;
  completedAt?: string;
}

export const saveToken = (token: string): void => {
  localStorage.setItem('cognitiveHub_token', token);
};

export const clearToken = (): void => {
  localStorage.removeItem('cognitiveHub_token');
  localStorage.removeItem('cognitiveHub_user');
};

export const saveUser = (user: User): void => {
  localStorage.setItem('cognitiveHub_user', JSON.stringify(user));
};

export const getUser = (): User | null => {
  const raw = localStorage.getItem('cognitiveHub_user');
  return raw ? JSON.parse(raw) : null;
};
