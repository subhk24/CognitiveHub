import { Wifi } from "lucide-react";

interface HeaderProps {
  subtitle?: string;
}

const Header = ({ subtitle }: HeaderProps) => {
  return (
    <div className="flex items-center justify-between px-4 py-3">
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-full gradient-primary flex items-center justify-center">
          <span className="text-xs font-bold text-primary-foreground">AI</span>
        </div>
        <div>
          <span className="font-display font-bold text-primary">Cognitive Hub</span>
          {subtitle && (
            <span className="ml-2 text-[10px] tracking-wider text-success uppercase">{subtitle}</span>
          )}
        </div>
      </div>
      <Wifi size={18} className="text-muted-foreground" />
    </div>
  );
};

export default Header;
