import { Sparkles, LayoutGrid, Settings, User, ListChecks, Trophy, MessageCircle } from "lucide-react";

interface BottomNavProps {
  active: string;
  onNavigate: (tab: string) => void;
}

const tabs = [
  { id: "nexus", label: "NEXUS", icon: Sparkles },
  { id: "vault", label: "VAULT", icon: LayoutGrid },
  { id: "tasks", label: "TASKS", icon: ListChecks },
  { id: "ranks", label: "RANKS", icon: Trophy },
  { id: "chat", label: "CHAT", icon: MessageCircle },
  { id: "synapse", label: "SYNAPSE", icon: Settings },
  { id: "profile", label: "PROFILE", icon: User },
];

const BottomNav = ({ active, onNavigate }: BottomNavProps) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 glass border-t border-border z-50">
      <div className="max-w-md mx-auto flex justify-around py-2 overflow-x-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = active === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onNavigate(tab.id)}
              className={`flex flex-col items-center gap-0.5 px-2 py-1.5 rounded-xl transition-all flex-shrink-0 ${
                isActive
                  ? "bg-primary/20 glow-purple"
                  : "opacity-50 hover:opacity-80"
              }`}
            >
              <Icon size={18} className={isActive ? "text-primary" : "text-muted-foreground"} />
              <span className={`text-[8px] tracking-widest font-medium ${isActive ? "text-primary" : "text-muted-foreground"}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNav;
