// Simulated multi-user data for daily tasks, leaderboard, and community
export interface DailyTask {
  id: string;
  title: string;
  description: string;
  xp: number;
  category: string;
  totalCompletions: number;
  difficulty: "easy" | "medium" | "hard";
}

export interface LeaderboardEntry {
  rank: number;
  name: string;
  avatar: string;
  score: number;
  tasksCompleted: number;
  streak: number;
  badge: string;
  trend: "up" | "down" | "same";
}

export interface ChatMessage {
  id: string;
  user: string;
  avatar: string;
  message: string;
  timestamp: string;
  likes: number;
  topic?: string;
}

export const dailyTasks: DailyTask[] = [
  { id: "t1", title: "Prompt Engineering Challenge", description: "Write a zero-shot prompt that generates a structured JSON output from unstructured text.", xp: 200, category: "AI Skills", totalCompletions: 342, difficulty: "medium" },
  { id: "t2", title: "Ethics Case Study", description: "Analyze the bias implications in a facial recognition dataset and propose mitigation strategies.", xp: 300, category: "AI Ethics", totalCompletions: 187, difficulty: "hard" },
  { id: "t3", title: "Model Evaluation Quiz", description: "Complete a 5-question quiz on precision, recall, F1-score and ROC curves.", xp: 150, category: "ML Fundamentals", totalCompletions: 521, difficulty: "easy" },
  { id: "t4", title: "RAG Architecture Design", description: "Design a retrieval-augmented generation pipeline for a customer support chatbot.", xp: 350, category: "Architecture", totalCompletions: 94, difficulty: "hard" },
  { id: "t5", title: "Fine-Tuning Basics", description: "Explain when to use fine-tuning vs few-shot prompting with real-world examples.", xp: 200, category: "AI Skills", totalCompletions: 278, difficulty: "medium" },
  { id: "t6", title: "Data Pipeline Review", description: "Identify 3 bottlenecks in a sample ETL pipeline diagram.", xp: 250, category: "Data Engineering", totalCompletions: 156, difficulty: "medium" },
];

export const leaderboardData: LeaderboardEntry[] = [
  { rank: 1, name: "Marcus Kane", avatar: "🧑‍💻", score: 9840, tasksCompleted: 156, streak: 42, badge: "AI Master", trend: "same" },
  { rank: 2, name: "Aria Montgomery", avatar: "👩‍🔬", score: 9210, tasksCompleted: 143, streak: 38, badge: "Neural Architect", trend: "up" },
  { rank: 3, name: "Kai Nakamura", avatar: "🧑‍🎓", score: 8750, tasksCompleted: 137, streak: 31, badge: "Prompt Wizard", trend: "up" },
  { rank: 4, name: "Sarah Liao", avatar: "👩‍💼", score: 8320, tasksCompleted: 128, streak: 27, badge: "Data Sage", trend: "down" },
  { rank: 5, name: "You", avatar: "⭐", score: 7890, tasksCompleted: 112, streak: 14, badge: "Rising Star", trend: "up" },
  { rank: 6, name: "Jordan Dale", avatar: "🧑‍🎨", score: 7450, tasksCompleted: 98, streak: 19, badge: "AI Explorer", trend: "down" },
  { rank: 7, name: "Priya Sharma", avatar: "👩‍🏫", score: 7100, tasksCompleted: 91, streak: 22, badge: "Ethics Champion", trend: "up" },
  { rank: 8, name: "Leo Chen", avatar: "🧑‍🔧", score: 6780, tasksCompleted: 85, streak: 11, badge: "Code Ninja", trend: "same" },
  { rank: 9, name: "Emma Wilson", avatar: "👩‍⚕️", score: 6340, tasksCompleted: 76, streak: 8, badge: "ML Apprentice", trend: "down" },
  { rank: 10, name: "Ravi Patel", avatar: "🧑‍💻", score: 5920, tasksCompleted: 69, streak: 15, badge: "AI Beginner", trend: "up" },
];

export const communityMessages: ChatMessage[] = [
  { id: "m1", user: "Aria Montgomery", avatar: "👩‍🔬", message: "Just completed the RAG Architecture challenge! The key insight was using hybrid search with both semantic and keyword matching. Anyone else try a different approach?", timestamp: "2 min ago", likes: 12, topic: "AI Architecture" },
  { id: "m2", user: "Kai Nakamura", avatar: "🧑‍🎓", message: "Has anyone noticed that chain-of-thought prompting works significantly better with longer context windows? I ran some experiments and got 23% improvement.", timestamp: "8 min ago", likes: 8, topic: "Prompt Engineering" },
  { id: "m3", user: "Sarah Liao", avatar: "👩‍💼", message: "The ethics case study today was eye-opening. I think we need to discuss more about fairness metrics in production ML systems.", timestamp: "15 min ago", likes: 21, topic: "AI Ethics" },
  { id: "m4", user: "Marcus Kane", avatar: "🧑‍💻", message: "Pro tip: When fine-tuning smaller models, use a learning rate warmup of 10% of total steps. It stabilizes training significantly.", timestamp: "23 min ago", likes: 34, topic: "ML Tips" },
  { id: "m5", user: "Priya Sharma", avatar: "👩‍🏫", message: "I'm organizing a study group for the upcoming Neural Architecture deep dive. Drop a 🧠 if you want to join!", timestamp: "31 min ago", likes: 15, topic: "Study Groups" },
  { id: "m6", user: "Leo Chen", avatar: "🧑‍🔧", message: "Just hit a 30-day streak! The gamification really keeps me motivated. What's everyone's current streak?", timestamp: "45 min ago", likes: 9, topic: "General" },
  { id: "m7", user: "Jordan Dale", avatar: "🧑‍🎨", message: "Can someone explain the difference between LoRA and QLoRA for fine-tuning? I'm confused about when to use each.", timestamp: "1 hr ago", likes: 6, topic: "ML Fundamentals" },
  { id: "m8", user: "Emma Wilson", avatar: "👩‍⚕️", message: "The healthcare AI module was fantastic. Really opened my eyes to how transformer models are being used in drug discovery.", timestamp: "1 hr ago", likes: 18, topic: "Healthcare AI" },
];

// Helper to manage completed tasks in localStorage
export const getCompletedTasks = (): string[] => {
  const stored = localStorage.getItem("cognitiveHub_completedTasks");
  return stored ? JSON.parse(stored) : [];
};

export const completeTask = (taskId: string): string[] => {
  const completed = getCompletedTasks();
  if (!completed.includes(taskId)) {
    completed.push(taskId);
    localStorage.setItem("cognitiveHub_completedTasks", JSON.stringify(completed));
  }
  return completed;
};

export const getUserXP = (): number => {
  const completed = getCompletedTasks();
  return dailyTasks
    .filter((t) => completed.includes(t.id))
    .reduce((sum, t) => sum + t.xp, 0);
};
