import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { TrendingUp, TrendingDown, Minus, Flame } from "lucide-react";
import Header from "@/components/Header";
import { leaderboardData } from "@/data/mockData";
import { io, Socket } from "socket.io-client";

interface LiveEntry {
  _id: string;
  name: string;
  score: number;
  xp: number;
  level: number;
  specialization?: string;
}

const timeFilters = ["This Week", "This Month", "All Time"];

const rankStyle = (rank: number) => {
  switch (rank) {
    case 1: return "bg-warning/20 border-warning/40 text-warning";
    case 2: return "bg-muted border-muted-foreground/20 text-muted-foreground";
    case 3: return "bg-warning/10 border-warning/20 text-warning/70";
    default: return "bg-card border-border text-muted-foreground";
  }
};

const rankEmoji = (rank: number) => {
  switch (rank) { case 1: return "🥇"; case 2: return "🥈"; case 3: return "🥉"; default: return `#${rank}`; }
};

const LeaderboardScreen = () => {
  const [activeFilter, setActiveFilter] = useState("This Week");
  const [liveEntries, setLiveEntries] = useState<LiveEntry[]>([]);
  const [live, setLive] = useState(false);
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    fetch('/api/test/leaderboard')
      .then((r) => r.json())
      .then((data) => { if (data.leaderboard?.length > 0) setLiveEntries(data.leaderboard); })
      .catch(() => {});
  }, []);

  useEffect(() => {
    const socket = io('/', { path: '/socket.io', transports: ['websocket', 'polling'] });
    socketRef.current = socket;

    socket.on('connect', () => setLive(true));
    socket.on('disconnect', () => setLive(false));
    socket.on('leaderboardUpdated', (data: { leaderboard: LiveEntry[] }) => {
      if (data.leaderboard?.length > 0) {
        setLiveEntries(data.leaderboard);
      }
    });

    return () => { socket.disconnect(); };
  }, []);

  const displayData = liveEntries.length > 0
    ? liveEntries.map((e, i) => ({
        rank: i + 1,
        name: e.name,
        avatar: ['🧠', '⚡', '🚀', '💡', '🎯', '🔥', '✨', '🌟'][i % 8],
        score: e.score,
        xp: e.xp,
        tasksCompleted: Math.floor(e.score / 10),
        streak: Math.floor(Math.random() * 30) + 1,
        badge: e.specialization ? e.specialization.charAt(0).toUpperCase() + e.specialization.slice(1) : 'Learner',
        trend: 'same' as const,
      }))
    : leaderboardData;

  const trendIcon = (trend: string) => {
    switch (trend) {
      case "up": return <TrendingUp size={12} className="text-success" />;
      case "down": return <TrendingDown size={12} className="text-destructive" />;
      default: return <Minus size={12} className="text-muted-foreground" />;
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <Header subtitle="RANKINGS" />
      <div className="px-5 pt-2">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-[10px] tracking-widest text-primary mb-1">COMPETITIVE ARENA</p>
              <h1 className="font-display text-3xl font-bold leading-tight">Leaderboard</h1>
            </div>
            <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-medium ${live ? "bg-success/10 text-success" : "bg-muted text-muted-foreground"}`}>
              <div className={`w-1.5 h-1.5 rounded-full ${live ? "bg-success animate-pulse" : "bg-muted-foreground"}`} />
              {live ? "LIVE" : "OFFLINE"}
            </div>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="flex gap-2 mt-4">
          {timeFilters.map((f) => (
            <button
              key={f}
              onClick={() => setActiveFilter(f)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${activeFilter === f ? "border-primary bg-primary/20 text-primary" : "border-border bg-card text-muted-foreground"}`}
            >
              {f}
            </button>
          ))}
        </motion.div>

        {/* Top 3 Podium */}
        {displayData.length >= 3 && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="mt-6">
            <div className="flex items-end justify-center gap-3">
              <div className="flex flex-col items-center">
                <span className="text-2xl mb-1">{displayData[1].avatar}</span>
                <div className="w-20 bg-muted/50 rounded-t-xl pt-3 pb-2 text-center border border-b-0 border-muted-foreground/10">
                  <p className="text-xs font-bold truncate px-1">{displayData[1].name.split(" ")[0]}</p>
                  <p className="text-[10px] text-muted-foreground">{displayData[1].score.toLocaleString()}</p>
                </div>
                <div className="w-20 h-20 bg-muted/30 flex items-center justify-center text-2xl rounded-b-lg">🥈</div>
              </div>
              <div className="flex flex-col items-center -mt-4">
                <span className="text-3xl mb-1">{displayData[0].avatar}</span>
                <div className="w-24 bg-warning/10 rounded-t-xl pt-3 pb-2 text-center border border-b-0 border-warning/20">
                  <p className="text-xs font-bold truncate px-1">{displayData[0].name.split(" ")[0]}</p>
                  <p className="text-[10px] text-warning">{displayData[0].score.toLocaleString()}</p>
                </div>
                <div className="w-24 h-28 bg-warning/5 flex items-center justify-center text-3xl rounded-b-lg border border-t-0 border-warning/10">🥇</div>
              </div>
              <div className="flex flex-col items-center">
                <span className="text-2xl mb-1">{displayData[2].avatar}</span>
                <div className="w-20 bg-warning/5 rounded-t-xl pt-3 pb-2 text-center border border-b-0 border-warning/10">
                  <p className="text-xs font-bold truncate px-1">{displayData[2].name.split(" ")[0]}</p>
                  <p className="text-[10px] text-muted-foreground">{displayData[2].score.toLocaleString()}</p>
                </div>
                <div className="w-20 h-16 bg-warning/5 flex items-center justify-center text-2xl rounded-b-lg">🥉</div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Full Rankings */}
        <div className="mt-6 space-y-2">
          {displayData.map((entry, i) => {
            const isYou = entry.name === "You";
            return (
              <motion.div
                key={entry.rank}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + i * 0.04 }}
                className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${isYou ? "border-primary bg-primary/10 glow-purple" : "border-border bg-card"}`}
              >
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold border ${rankStyle(entry.rank)}`}>
                  {entry.rank <= 3 ? rankEmoji(entry.rank) : entry.rank}
                </div>
                <span className="text-xl">{entry.avatar}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className={`font-bold text-sm truncate ${isYou ? "text-primary" : ""}`}>{entry.name}</p>
                    {trendIcon(entry.trend)}
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-[9px] text-muted-foreground">{entry.tasksCompleted} tasks</span>
                    <span className="flex items-center gap-0.5 text-[9px] text-warning">
                      <Flame size={9} /> {entry.streak}d
                    </span>
                    <span className="text-[9px] bg-muted px-1.5 py-0.5 rounded text-muted-foreground">{entry.badge}</span>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-display font-bold text-sm">{entry.score.toLocaleString()}</p>
                  <p className="text-[9px] text-muted-foreground">XP</p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default LeaderboardScreen;
