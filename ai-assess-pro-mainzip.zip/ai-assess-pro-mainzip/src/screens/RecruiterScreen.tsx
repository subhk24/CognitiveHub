import { useState } from "react";
import { motion } from "framer-motion";
import { Filter, Plus } from "lucide-react";
import Header from "@/components/Header";

const candidates = [
  {
    name: "Marcus Kane",
    role: "Lead Systems Architect • 8+ years exp.",
    score: 98.4,
    adaptability: "A+",
    stack: "Rust, Go, K8s",
    status: "Interviewing",
    tags: ["ML", "OPS", "DS"],
    badge: "Industry Ready",
    badgeColor: "bg-success text-success-foreground",
  },
  {
    name: "Sarah Liao",
    role: "Senior Data Analyst",
    score: 82,
    adaptability: "B+",
    stack: "Python, SQL",
    status: "Screening",
    tags: ["DA", "ML"],
    badge: "Almost Ready",
    badgeColor: "bg-warning text-warning-foreground",
  },
  {
    name: "Jordan Dale",
    role: "Junior Dev Enthusiast",
    score: 45,
    adaptability: "C",
    stack: "JS, HTML",
    status: "Pending",
    tags: ["FE"],
    badge: "Not Ready",
    badgeColor: "bg-destructive text-destructive-foreground",
  },
  {
    name: "Aria Montgomery",
    role: "Cloud Solutions Architect • AI Specialist",
    score: 96,
    adaptability: "A+",
    stack: "TensorFlow, PyTorch",
    status: "Interviewing",
    tags: ["TENSORFLOW", "PYTORCH", "AWS SAGEMAKER", "LLM TUNING"],
    badge: "Industry Ready",
    badgeColor: "bg-success text-success-foreground",
  },
];

const filters = ["All Candidates", "Skill: Python", "Specialization: ML", "Sort: Score"];

const RecruiterScreen = () => {
  const [activeFilters, setActiveFilters] = useState<string[]>(["All Candidates"]);
  const [minScore, setMinScore] = useState(0);

  const filtered = candidates.filter((c) => c.score >= minScore);

  const toggleFilter = (f: string) => {
    if (f === "All Candidates") {
      setActiveFilters(["All Candidates"]);
      setMinScore(0);
    } else {
      setActiveFilters((prev) =>
        prev.includes(f) ? prev.filter((x) => x !== f) : [...prev.filter((x) => x !== "All Candidates"), f]
      );
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <Header />
      <div className="px-5 pt-2">
        <p className="text-[10px] tracking-widest text-muted-foreground font-mono">RECRUITMENT_ORCHESTRATOR_V2.4</p>
        <h1 className="font-display text-3xl font-bold mt-1">Talent Pipeline</h1>

        {/* Filters */}
        <div className="flex flex-wrap gap-2 mt-4">
          {filters.map((f) => (
            <button
              key={f}
              onClick={() => toggleFilter(f)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                activeFilters.includes(f)
                  ? "border-primary bg-primary/20 text-primary"
                  : "border-border bg-card text-muted-foreground hover:border-primary/40"
              }`}
            >
              {f.startsWith("Sort") && <Filter size={10} className="inline mr-1" />}
              {f}
            </button>
          ))}
        </div>

        {/* Score filter */}
        <div className="mt-3 flex items-center gap-3">
          <span className="text-xs text-muted-foreground">Min Score:</span>
          <input
            type="range"
            min={0}
            max={100}
            value={minScore}
            onChange={(e) => setMinScore(Number(e.target.value))}
            className="flex-1 h-1 bg-secondary rounded-full appearance-none [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-primary"
          />
          <span className="text-xs font-mono text-primary w-8">{minScore}</span>
        </div>

        {/* Candidate Cards */}
        <div className="mt-5 space-y-4">
          {filtered.map((c, i) => (
            <motion.div
              key={c.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-card rounded-2xl p-5 border border-border relative"
            >
              {/* Badge */}
              <div className="absolute top-4 right-4">
                <span className={`text-[10px] px-2 py-1 rounded-full font-bold ${c.badgeColor}`}>
                  {c.badge === "Industry Ready" && "● "}
                  {c.badge}
                </span>
              </div>

              {/* Avatar */}
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/30 to-accent/20 flex items-center justify-center mb-3 border border-primary/20">
                <span className="text-2xl">{c.name[0]}</span>
              </div>

              <h3 className="font-display font-bold text-lg">{c.name}</h3>
              <p className="text-xs text-muted-foreground">{c.role}</p>

              {/* Stats */}
              {c.score >= 80 && (
                <div className="grid grid-cols-2 gap-2 mt-3">
                  <div className="bg-secondary/50 rounded-lg p-2">
                    <p className="text-[9px] tracking-widest text-muted-foreground">COGNITIVE SCORE</p>
                    <p className="font-display font-bold text-lg">{c.score}%</p>
                  </div>
                  <div className="bg-secondary/50 rounded-lg p-2">
                    <p className="text-[9px] tracking-widest text-muted-foreground">ADAPTABILITY</p>
                    <p className="font-display font-bold text-lg">{c.adaptability}</p>
                  </div>
                  <div className="bg-secondary/50 rounded-lg p-2">
                    <p className="text-[9px] tracking-widest text-muted-foreground">CORE STACK</p>
                    <p className="font-mono text-xs">{c.stack}</p>
                  </div>
                  <div className="bg-secondary/50 rounded-lg p-2">
                    <p className="text-[9px] tracking-widest text-muted-foreground">STATUS</p>
                    <p className="text-xs font-medium">{c.status}</p>
                  </div>
                </div>
              )}

              {/* Low score - proficiency gap */}
              {c.score < 80 && c.score >= 60 && (
                <div className="mt-3 bg-secondary/50 rounded-lg p-3">
                  <div className="flex justify-between mb-1">
                    <span className="text-[9px] tracking-widest text-muted-foreground">PROFICIENCY GAP</span>
                    <span className="text-sm font-bold">{c.score}%</span>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                    <div className="h-full gradient-primary rounded-full" style={{ width: `${c.score}%` }} />
                  </div>
                </div>
              )}

              {c.score < 60 && (
                <p className="text-xs text-muted-foreground mt-3 leading-relaxed">
                  Requires foundational training in distributed systems and advanced cloud architecture before deployment.
                </p>
              )}

              {/* Tags */}
              <div className="flex flex-wrap gap-1 mt-3">
                {c.tags.map((tag) => (
                  <span key={tag} className="text-[9px] tracking-wider bg-muted px-2 py-0.5 rounded font-mono">{tag}</span>
                ))}
              </div>

              <button className="mt-3 text-xs border border-border rounded-full px-4 py-2 hover:border-primary/50 transition-colors">
                View detailed report
              </button>
            </motion.div>
          ))}
        </div>

        {/* FAB */}
        <button className="fixed bottom-20 right-4 w-12 h-12 rounded-full gradient-primary flex items-center justify-center glow-purple">
          <Plus size={20} className="text-primary-foreground" />
        </button>
      </div>
    </div>
  );
};

export default RecruiterScreen;
