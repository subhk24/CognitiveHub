import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { CheckCircle, User, MessageSquare, Mic, MicOff } from "lucide-react";
import Header from "@/components/Header";
import { api } from "@/lib/api";

interface InterviewScreenProps {
  onComplete: () => void;
}

const InterviewScreen = ({ onComplete }: InterviewScreenProps) => {
  const [interviewId, setInterviewId] = useState<string | null>(null);
  const [question, setQuestion] = useState("How would you architect a decentralized cognitive node that maintains data integrity during a high-latency network partition?");
  const [transcript, setTranscript] = useState<{ timestamp: string; text: string }[]>([
    { timestamp: "04:12", text: '"I believe the foundation of such an architecture would require consensus mechanisms adapted for...' }
  ]);
  const [humanRequested, setHumanRequested] = useState(false);
  const [humanComplete, setHumanComplete] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  useEffect(() => {
    const token = localStorage.getItem("cognitiveHub_token");
    if (token) {
      api.interview.start().then((data) => {
        setInterviewId(data.interview._id);
        setQuestion(data.interview.question);
      }).catch(() => {});
    }
  }, []);

  const startRecording = () => {
    const SpeechRecognition = (window as unknown as { SpeechRecognition?: typeof globalThis.SpeechRecognition; webkitSpeechRecognition?: typeof globalThis.SpeechRecognition }).SpeechRecognition || (window as unknown as { webkitSpeechRecognition?: typeof globalThis.SpeechRecognition }).webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    recognitionRef.current = new SpeechRecognition();
    recognitionRef.current.continuous = true;
    recognitionRef.current.interimResults = true;

    recognitionRef.current.onresult = (event: SpeechRecognitionEvent) => {
      const last = Array.from(event.results).pop();
      if (last?.isFinal) {
        const text = last[0].transcript;
        const timestamp = new Date().toLocaleTimeString("en-US", { hour12: false, hour: "2-digit", minute: "2-digit" });
        setTranscript((prev) => [...prev, { timestamp, text: `"${text}"` }]);

        if (interviewId) {
          const token = localStorage.getItem("cognitiveHub_token");
          if (token) {
            api.interview.saveTranscript(interviewId, text, "user").catch(() => {});
          }
        }
      }
    };

    recognitionRef.current.start();
    setIsRecording(true);
  };

  const stopRecording = () => {
    recognitionRef.current?.stop();
    setIsRecording(false);
  };

  const requestHuman = async () => {
    setHumanRequested(true);
    if (interviewId) {
      const token = localStorage.getItem("cognitiveHub_token");
      if (token) {
        try {
          await api.interview.requestHumanReview(interviewId);
        } catch {}
      }
    }
    setTimeout(() => setHumanComplete(true), 2000);
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <Header subtitle="LIVE LINK" />
      <div className="px-5 pt-2">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="relative">
          <div className="rounded-2xl overflow-hidden bg-gradient-to-b from-primary/20 to-card border border-border">
            <div className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <User size={16} className="text-primary" />
                <span className="font-mono text-xs font-bold">AI CONDUCTOR: PHX-7</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 rounded-full bg-destructive animate-pulse" />
                <span className="text-[10px] tracking-wider text-destructive">RECORDING</span>
              </div>
            </div>
            
            <div className="h-48 flex items-center justify-center relative">
              <div className="w-32 h-32 rounded-full bg-gradient-to-br from-primary/30 to-accent/20 flex items-center justify-center border border-primary/20">
                <div className="w-24 h-24 rounded-full bg-card flex items-center justify-center">
                  <span className="text-4xl">🤖</span>
                </div>
              </div>
            </div>

            <div className="glass mx-4 mb-4 rounded-xl p-4">
              <p className="font-display font-bold text-sm leading-relaxed">
                "{question}"
              </p>
            </div>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="mt-4">
          <div className="glass rounded-2xl p-4 flex items-center gap-4">
            <div className="w-16 h-16 rounded-xl bg-card border border-border flex items-center justify-center">
              <span className="text-2xl">👤</span>
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 text-primary">
                  <MessageSquare size={14} />
                </div>
                <span className="text-xs text-muted-foreground">
                  {isRecording ? "Listening to your response..." : "Click mic to start speaking"}
                </span>
              </div>
              <p className="text-[10px] tracking-wider text-muted-foreground mt-1">YOU (SELF)</p>
            </div>
            <div className="flex flex-col items-center gap-1">
              <button
                onClick={isRecording ? stopRecording : startRecording}
                className={`p-2 rounded-full transition-all ${isRecording ? "bg-destructive/20 text-destructive animate-pulse" : "bg-primary/20 text-primary hover:bg-primary/30"}`}
              >
                {isRecording ? <MicOff size={18} /> : <Mic size={18} />}
              </button>
              <p className="text-[10px] tracking-wider text-muted-foreground">STRESS THRESHOLD</p>
              <div className="flex gap-1 mt-1">
                {[...Array(7)].map((_, i) => (
                  <div key={i} className={`w-3 h-3 rounded-full ${i < 4 ? "bg-primary" : "bg-primary/20"}`} />
                ))}
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="mt-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="text-lg">💬</span>
              <span className="font-display font-bold text-sm tracking-wider">TRANSCRIPTION</span>
            </div>
            <span className="text-[10px] tracking-wider text-success">LIVE UPDATING</span>
          </div>
          <div className="bg-card rounded-xl p-4 border border-border space-y-2 max-h-32 overflow-y-auto">
            {transcript.map((entry, i) => (
              <div key={i} className="flex gap-3">
                <span className="text-xs text-muted-foreground font-mono shrink-0">{entry.timestamp}</span>
                <p className="text-sm text-muted-foreground">{entry.text}</p>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="mt-6">
          <div className="bg-card rounded-2xl p-5 border border-success/20">
            <div className="flex items-center gap-3 mb-3">
              <CheckCircle size={20} className="text-success" />
              <span className="font-display font-bold">AI Evaluation Complete</span>
            </div>
            <p className="text-sm text-muted-foreground">The AI has analyzed your responses across problem-solving, communication, and domain expertise.</p>
          </div>
        </motion.div>

        {!humanRequested ? (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="mt-4">
            <button
              onClick={requestHuman}
              className="w-full py-4 rounded-2xl border-2 border-dashed border-primary/40 text-primary font-display font-bold flex items-center justify-center gap-2 hover:bg-primary/5 transition-all"
            >
              <User size={18} /> Request Human Review
            </button>
            <p className="text-center text-xs text-muted-foreground mt-2">Add depth and credibility with expert validation</p>
          </motion.div>
        ) : !humanComplete ? (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-4">
            <div className="bg-card rounded-2xl p-5 border border-border text-center">
              <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-3" />
              <p className="font-display font-bold">Matching with Expert Reviewer...</p>
              <p className="text-xs text-muted-foreground mt-1">Estimated wait: 2-3 minutes</p>
            </div>
          </motion.div>
        ) : (
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="mt-4">
            <div className="bg-card rounded-2xl p-5 border border-success/20">
              <div className="flex items-center gap-3 mb-3">
                <CheckCircle size={20} className="text-success" />
                <span className="font-display font-bold">Human Review Complete</span>
              </div>
              <div className="space-y-3 mt-3">
                <div className="bg-secondary/50 rounded-xl p-3">
                  <p className="text-xs font-bold text-success mb-1">Strengths Noted</p>
                  <p className="text-sm text-muted-foreground">Strong architectural thinking. Excellent understanding of distributed systems and consensus mechanisms.</p>
                </div>
                <div className="bg-secondary/50 rounded-xl p-3">
                  <p className="text-xs font-bold text-warning mb-1">Areas for Growth</p>
                  <p className="text-sm text-muted-foreground">Could elaborate more on edge-case handling for network partitions. Consider CAP theorem implications.</p>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {humanComplete && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mt-6">
            <button onClick={onComplete} className="w-full py-4 rounded-2xl gradient-cta text-primary-foreground font-display font-bold text-lg transition-transform hover:scale-[1.02] active:scale-[0.98]">
              View Transparency Dashboard
            </button>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default InterviewScreen;
