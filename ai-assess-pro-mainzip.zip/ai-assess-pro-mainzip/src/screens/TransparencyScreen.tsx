import { useState } from "react";
import { motion } from "framer-motion";
import { ChevronDown, CheckCircle, AlertTriangle } from "lucide-react";
import Header from "@/components/Header";

interface TransparencyScreenProps {
  score: number;
  onComplete: () => void;
}

const TransparencyScreen = ({ score, onComplete }: TransparencyScreenProps) => {
  const [showWhy, setShowWhy] = useState(false);
  const tier = score >= 90 ? "Master Tier" : score >= 75 ? "Expert Tier" : score >= 50 ? "Intermediate" : "Beginner";
  
  const dimensions = [
    { label: "PROMPT WRITING", value: 92 },
    { label: "AI ETHICS", value: 65 },
    { label: "PROBLEM SOLVING", value: 84 },
    { label: "DOMAIN KNOWLEDGE", value: 78 },
    { label: "AI TOOL USAGE", value: 71 },
  ];

  const strengths = [
    "Exceptional use of few-shot prompting techniques to guide model output.",
    "Strong iterative refinement cycles during complex logic tasks.",
  ];

  const growthAreas = [
    "Tendency to provide redundant constraints in creative prompts.",
    "Inconsistent application of safety filters during edge-case testing.",
  ];

  // Efficiency map colors
  const mapColors = [
    ["bg-primary/80", "bg-primary", "bg-primary/60", "bg-primary/40", "bg-primary/30", "bg-muted"],
    ["bg-primary/70", "bg-primary/90", "bg-primary/50", "bg-primary/30", "bg-muted", "bg-muted/50"],
  ];

  return (
    <div className="min-h-screen bg-background pb-24">
      <Header />
      <div className="px-5 pt-4">
        {/* Score Ring */}
        <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-col items-center">
          <div className="relative w-44 h-44">
            <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
              <circle cx="50" cy="50" r="42" fill="none" stroke="hsl(225 20% 14%)" strokeWidth="6" />
              <circle
                cx="50" cy="50" r="42" fill="none"
                stroke="url(#scoreGrad)" strokeWidth="6"
                strokeDasharray={`${(score / 100) * 264} 264`}
                strokeLinecap="round"
              />
              <defs>
                <linearGradient id="scoreGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="hsl(262, 80%, 60%)" />
                  <stop offset="100%" stopColor="hsl(190, 90%, 50%)" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-[10px] tracking-widest text-muted-foreground">AI PROFICIENCY</span>
              <span className="font-display text-4xl font-bold">{score}<span className="text-lg">%</span></span>
              <span className="text-xs bg-primary/20 text-primary px-3 py-0.5 rounded-full mt-1">{tier}</span>
            </div>
          </div>
        </motion.div>

        {/* Synapse Insights */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="mt-6">
          <h2 className="font-display text-2xl font-bold">Synapse Insights</h2>
          <p className="text-sm text-muted-foreground mt-2 leading-relaxed">
            Your cognitive alignment has increased by 12% this session. Neural mapping suggests high proficiency in abstract reasoning.
          </p>
        </motion.div>

        {/* Dimension Bars */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="mt-6 space-y-4">
          {dimensions.map((dim) => (
            <div key={dim.label}>
              <div className="flex justify-between mb-1">
                <span className="text-[10px] tracking-widest text-muted-foreground">{dim.label}</span>
                <span className={`text-sm font-bold ${dim.value >= 80 ? "text-success" : dim.value >= 60 ? "text-warning" : "text-destructive"}`}>{dim.value}%</span>
              </div>
              <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${dim.value}%` }}
                  transition={{ delay: 0.5, duration: 0.8 }}
                  className="h-full rounded-full"
                  style={{ background: `linear-gradient(90deg, hsl(262, 80%, 60%), hsl(${dim.value > 80 ? 142 : 262}, 70%, 50%))` }}
                />
              </div>
            </div>
          ))}
        </motion.div>

        {/* Core Strengths */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="mt-6">
          <div className="bg-card rounded-2xl p-5 border border-success/20">
            <div className="flex items-center gap-2 mb-3">
              <CheckCircle size={18} className="text-success" />
              <h3 className="font-display font-bold">Core Strengths</h3>
            </div>
            <ul className="space-y-2">
              {strengths.map((s, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-success mt-1.5 flex-shrink-0" />
                  <p className="text-sm text-muted-foreground">{s}</p>
                </li>
              ))}
            </ul>
          </div>
        </motion.div>

        {/* Growth Areas */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="mt-4">
          <div className="bg-card rounded-2xl p-5 border border-warning/20">
            <div className="flex items-center gap-2 mb-3">
              <AlertTriangle size={18} className="text-warning" />
              <h3 className="font-display font-bold">Growth Areas</h3>
            </div>
            <ul className="space-y-2">
              {growthAreas.map((g, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-warning mt-1.5 flex-shrink-0" />
                  <p className="text-sm text-muted-foreground">{g}</p>
                </li>
              ))}
            </ul>
          </div>
        </motion.div>

        {/* Efficiency Map */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }} className="mt-6">
          <div className="flex justify-between items-center mb-3">
            <h3 className="font-display font-bold">Efficiency Map</h3>
            <span className="text-[10px] tracking-widest text-muted-foreground">DIFFICULTY VS TIME</span>
          </div>
          <div className="space-y-1">
            {mapColors.map((row, ri) => (
              <div key={ri} className="flex gap-1">
                {row.map((color, ci) => (
                  <div key={ci} className={`flex-1 h-10 rounded-md ${color}`} />
                ))}
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-1">
            <span className="text-[10px] text-muted-foreground">0min</span>
            <span className="text-[10px] text-muted-foreground">60min</span>
          </div>
        </motion.div>

        {/* Why this score */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7 }} className="mt-6">
          <button onClick={() => setShowWhy(!showWhy)} className="w-full flex items-center justify-between p-4 bg-card rounded-xl border border-border">
            <div className="flex items-center gap-2">
              <span className="text-primary">💡</span>
              <div className="text-left">
                <p className="font-display font-bold text-sm">Why this score?</p>
                <p className="text-xs text-muted-foreground">Deep dive into the neural attribution model.</p>
              </div>
            </div>
            <ChevronDown size={18} className={`text-muted-foreground transition-transform ${showWhy ? "rotate-180" : ""}`} />
          </button>
          {showWhy && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} className="mt-2 bg-card rounded-xl p-4 border border-border">
              <p className="text-sm text-muted-foreground leading-relaxed">
                Your score is computed using a weighted combination of accuracy (40%), confidence calibration (20%), response consistency (15%), domain depth (15%), and adaptive performance (10%). The AI noted strong performance on medium-difficulty questions with high confidence calibration, contributing positively to your overall assessment.
              </p>
            </motion.div>
          )}
        </motion.div>

        {/* Continue */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.8 }} className="mt-6">
          <button onClick={onComplete} className="w-full py-4 rounded-2xl gradient-cta text-primary-foreground font-display font-bold text-lg transition-transform hover:scale-[1.02] active:scale-[0.98]">
            View Growth Dashboard
          </button>
        </motion.div>
      </div>
    </div>
  );
};

export default TransparencyScreen;
