import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Mic, Zap, X, GraduationCap, Palette, Briefcase, HeartPulse, Search, Loader } from "lucide-react";
import Header from "@/components/Header";

interface OnboardingScreenProps {
  onComplete: () => void;
}

const specializations = [
  { id: "engineering", label: "ENGINEERING", icon: GraduationCap },
  { id: "design", label: "DESIGN", icon: Palette },
  { id: "mba", label: "MBA", icon: Briefcase },
  { id: "healthcare", label: "HEALTHCARE", icon: HeartPulse },
];

const OnboardingScreen = ({ onComplete }: OnboardingScreenProps) => {
  const [selectedSpec, setSelectedSpec] = useState<string | null>(null);
  const [skills, setSkills] = useState<string[]>(["Python", "React"]);
  const [projects, setProjects] = useState<string[]>(["Neural Link"]);
  const [newSkill, setNewSkill] = useState("");
  const [newProject, setNewProject] = useState("");
  const [projectDescription, setProjectDescription] = useState("");
  const [analyzing, setAnalyzing] = useState(false);
  const [analyzeResult, setAnalyzeResult] = useState<{ detectedSkills: string[]; suggestedTopics: string[]; suggestedWeakAreas: string[] } | null>(null);
  const [showAnalyze, setShowAnalyze] = useState(false);

  const handleStart = () => {
    const profile = {
      name: "Student",
      specialization: selectedSpec,
      skills,
      projects,
      weakAreas: analyzeResult?.suggestedWeakAreas || [],
      createdAt: new Date().toISOString(),
    };
    localStorage.setItem("cognitiveHub_profile", JSON.stringify(profile));
    onComplete();
  };

  const handleAnalyze = async () => {
    if (!projectDescription.trim()) return;
    setAnalyzing(true);
    setAnalyzeResult(null);
    try {
      const res = await fetch('/api/project/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectDescription }),
      });
      const data = await res.json();
      setAnalyzeResult(data);
      const newSkills = data.detectedSkills.filter((s: string) => !skills.includes(s));
      if (newSkills.length > 0) {
        setSkills((prev) => [...prev, ...newSkills]);
      }
    } catch {
      setAnalyzeResult({ detectedSkills: [], suggestedTopics: [], suggestedWeakAreas: [] });
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <Header />
      <div className="px-5 pt-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="font-display text-4xl font-bold leading-tight">
            Your Future,<br />
            <span className="text-foreground">Architected.</span>
          </h1>
          <p className="text-muted-foreground mt-3 text-sm leading-relaxed">
            Join a diverse community of learners. Our AI engine builds a personalized proficiency path just for you.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="mt-5 rounded-2xl overflow-hidden h-40 bg-gradient-to-br from-primary/20 to-secondary flex items-center justify-center"
        >
          <div className="text-center">
            <div className="flex gap-3 justify-center mb-2">
              <div className="w-16 h-16 rounded-full bg-primary/30 animate-pulse-glow" />
              <div className="w-16 h-16 rounded-full bg-accent/30 animate-pulse-glow" style={{ animationDelay: "0.5s" }} />
              <div className="w-16 h-16 rounded-full bg-success/30 animate-pulse-glow" style={{ animationDelay: "1s" }} />
            </div>
            <p className="text-xs text-muted-foreground">Diverse Learners Community</p>
          </div>
        </motion.div>

        {/* Specialization */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="mt-8">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-lg">🎯</span>
            <h2 className="font-display font-bold text-lg">Choose Your Specialization</h2>
          </div>
          <p className="text-muted-foreground text-xs mb-4">Where do you want to lead the future?</p>
          <div className="grid grid-cols-2 gap-3">
            {specializations.map((spec) => {
              const Icon = spec.icon;
              const isSelected = selectedSpec === spec.id;
              return (
                <button
                  key={spec.id}
                  onClick={() => setSelectedSpec(spec.id)}
                  className={`flex flex-col items-center gap-2 p-4 rounded-xl border transition-all ${
                    isSelected ? "border-primary bg-primary/10 glow-purple" : "border-border bg-card hover:border-primary/50"
                  }`}
                >
                  <Icon size={24} className={isSelected ? "text-primary" : "text-muted-foreground"} />
                  <span className="text-xs tracking-wider font-medium">{spec.label}</span>
                </button>
              );
            })}
          </div>
        </motion.div>

        {/* Core Skills */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="mt-8">
          <div className="flex items-center gap-2 mb-3">
            <span className="text-lg">💻</span>
            <h2 className="font-display font-bold text-lg">Core Skills</h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {skills.map((skill) => (
              <span key={skill} className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-primary/20 text-primary text-sm border border-primary/30">
                {skill}
                <button onClick={() => setSkills(skills.filter((s) => s !== skill))}><X size={12} /></button>
              </span>
            ))}
            <input
              value={newSkill}
              onChange={(e) => setNewSkill(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && newSkill.trim()) {
                  setSkills([...skills, newSkill.trim()]);
                  setNewSkill("");
                }
              }}
              placeholder="+ Add Skill"
              className="bg-transparent border border-dashed border-muted-foreground/30 rounded-full px-3 py-1.5 text-sm w-24 focus:outline-none focus:border-primary"
            />
          </div>
        </motion.div>

        {/* Recent Projects */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="mt-8">
          <div className="flex items-center gap-2 mb-3">
            <span className="text-lg">🚀</span>
            <h2 className="font-display font-bold text-lg">Recent Projects</h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {projects.map((proj) => (
              <span key={proj} className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-success/20 text-success text-sm border border-success/30">
                {proj}
                <button onClick={() => setProjects(projects.filter((p) => p !== proj))}><X size={12} /></button>
              </span>
            ))}
            <input
              value={newProject}
              onChange={(e) => setNewProject(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && newProject.trim()) {
                  setProjects([...projects, newProject.trim()]);
                  setNewProject("");
                }
              }}
              placeholder="+ Add Project"
              className="bg-transparent border border-dashed border-muted-foreground/30 rounded-full px-3 py-1.5 text-sm w-28 focus:outline-none focus:border-primary"
            />
          </div>
        </motion.div>

        {/* Explain Your Project */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }} className="mt-8">
          <div className="glass rounded-2xl p-5">
            <button
              onClick={() => setShowAnalyze(!showAnalyze)}
              className="w-full flex items-center gap-3 text-left"
            >
              <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                <Search size={18} className="text-primary" />
              </div>
              <div className="flex-1">
                <p className="font-display font-bold text-sm">Explain Your Project</p>
                <p className="text-muted-foreground text-xs mt-0.5">AI detects your skills from your description</p>
              </div>
              <span className="text-muted-foreground text-sm">{showAnalyze ? "▲" : "▼"}</span>
            </button>

            <AnimatePresence>
              {showAnalyze && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="overflow-hidden"
                >
                  <div className="mt-4">
                    <textarea
                      value={projectDescription}
                      onChange={(e) => setProjectDescription(e.target.value)}
                      placeholder="e.g. I built a full-stack app using React, Node.js, MongoDB and JWT authentication. The backend uses Express with REST APIs..."
                      rows={4}
                      className="w-full bg-card border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-primary resize-none"
                    />
                    <button
                      onClick={handleAnalyze}
                      disabled={!projectDescription.trim() || analyzing}
                      className="mt-3 w-full py-2.5 rounded-xl bg-primary/20 border border-primary/30 text-primary font-medium text-sm flex items-center justify-center gap-2 disabled:opacity-40 hover:bg-primary/30 transition-all"
                    >
                      {analyzing ? (
                        <><Loader size={14} className="animate-spin" /> Analyzing...</>
                      ) : (
                        <><Mic size={14} /> Analyze & Auto-detect Skills</>
                      )}
                    </button>

                    {analyzeResult && (
                      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="mt-4 space-y-3">
                        {analyzeResult.detectedSkills.length > 0 && (
                          <div>
                            <p className="text-[10px] tracking-widest font-bold text-success mb-2">✓ SKILLS DETECTED & ADDED</p>
                            <div className="flex flex-wrap gap-1.5">
                              {analyzeResult.detectedSkills.map((s) => (
                                <span key={s} className="px-2.5 py-1 rounded-full bg-success/20 text-success text-xs border border-success/30">{s}</span>
                              ))}
                            </div>
                          </div>
                        )}
                        {analyzeResult.suggestedTopics.length > 0 && (
                          <div>
                            <p className="text-[10px] tracking-widest font-bold text-primary mb-2">📚 SUGGESTED STUDY TOPICS</p>
                            <div className="flex flex-wrap gap-1.5">
                              {analyzeResult.suggestedTopics.map((t) => (
                                <span key={t} className="px-2.5 py-1 rounded-full bg-primary/10 text-primary text-xs border border-primary/20">{t}</span>
                              ))}
                            </div>
                          </div>
                        )}
                        {analyzeResult.suggestedWeakAreas.length > 0 && (
                          <div>
                            <p className="text-[10px] tracking-widest font-bold text-warning mb-2">⚠ AREAS TO FOCUS ON</p>
                            <div className="flex flex-wrap gap-1.5">
                              {analyzeResult.suggestedWeakAreas.map((w) => (
                                <span key={w} className="px-2.5 py-1 rounded-full bg-warning/10 text-warning text-xs border border-warning/20">{w}</span>
                              ))}
                            </div>
                          </div>
                        )}
                        {analyzeResult.detectedSkills.length === 0 && (
                          <p className="text-sm text-muted-foreground">No specific technologies detected. Try describing your project with more technical details.</p>
                        )}
                      </motion.div>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>

        {/* CTA */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7 }} className="mt-8">
          <button
            onClick={handleStart}
            className="w-full py-4 rounded-2xl gradient-cta text-primary-foreground font-display font-bold text-lg flex items-center justify-center gap-2 glow-purple transition-transform hover:scale-[1.02] active:scale-[0.98]"
          >
            Start AI Assessment <Zap size={20} />
          </button>
        </motion.div>
      </div>
    </div>
  );
};

export default OnboardingScreen;
