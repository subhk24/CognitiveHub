import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { HelpCircle } from "lucide-react";
import Header from "@/components/Header";
import { api } from "@/lib/api";

interface AdaptiveTestScreenProps {
  onComplete: (score: number) => void;
}

const defaultQuestions = [
  {
    _id: "q1",
    category: "COMPLEX ANALYTICS",
    question: 'If the cognitive load of a neural subset increases by 14% every cycle, what is the asymptotic efficiency after n iterations?',
    options: ["Logarithmic divergence at n=10", "Linear stabilization at cycle peak", "Exponential decay of output parity", "Recursive entropy amplification"],
    correct: 1,
    difficulty: "hard",
    explanation: "This question tests your understanding of iterative computational processes and asymptotic analysis in neural network contexts.",
    tags: [],
  },
  {
    _id: "q2",
    category: "AI FUNDAMENTALS",
    question: "Which technique is most effective for reducing hallucination in large language models?",
    options: ["Increasing temperature parameter", "Retrieval-augmented generation (RAG)", "Removing attention layers", "Expanding context window only"],
    correct: 1,
    difficulty: "medium",
    explanation: "RAG grounds model outputs in retrieved factual documents.",
    tags: [],
  },
  {
    _id: "q3",
    category: "PROMPT ENGINEERING",
    question: "What is the primary benefit of chain-of-thought prompting?",
    options: ["Reduces token usage significantly", "Improves reasoning by breaking down steps", "Eliminates need for fine-tuning", "Increases model training speed"],
    correct: 1,
    difficulty: "medium",
    explanation: "Chain-of-thought prompting guides the model to reason step by step.",
    tags: [],
  },
  {
    _id: "q4",
    category: "NEURAL ARCHITECTURE",
    question: "In transformer models, what does the attention mechanism primarily compute?",
    options: ["Gradient descent optimization", "Weighted relevance between tokens", "Backpropagation error signals", "Loss function minimization"],
    correct: 1,
    difficulty: "hard",
    explanation: "Attention computes a weighted sum based on query-key similarity.",
    tags: [],
  },
  {
    _id: "q5",
    category: "AI ETHICS",
    question: "Which approach best addresses bias in AI training data?",
    options: ["Using larger datasets only", "Diverse data sourcing and regular audits", "Removing all demographic data", "Increasing model parameters"],
    correct: 1,
    difficulty: "medium",
    explanation: "Diverse sourcing combined with regular bias audits is most comprehensive.",
    tags: [],
  },
  {
    _id: "q6",
    category: "MACHINE LEARNING",
    question: "What is the vanishing gradient problem most associated with?",
    options: ["Convolutional neural networks", "Deep recurrent neural networks", "Decision tree ensembles", "Linear regression models"],
    correct: 1,
    difficulty: "hard",
    explanation: "Deep RNNs suffer most from vanishing gradients.",
    tags: [],
  },
  {
    _id: "q7",
    category: "AI TOOLS",
    question: "Which metric best evaluates a generative model's output quality?",
    options: ["Mean squared error only", "Human evaluation combined with automated metrics", "Training loss convergence", "Parameter count comparison"],
    correct: 1,
    difficulty: "medium",
    explanation: "Combining human judgment with automated metrics gives the most reliable quality assessment.",
    tags: [],
  },
];

const AdaptiveTestScreen = ({ onComplete }: AdaptiveTestScreenProps) => {
  const [questions, setQuestions] = useState(defaultQuestions);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [currentQ, setCurrentQ] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [confidence, setConfidence] = useState(70);
  const [timer, setTimer] = useState(522);
  const [answers, setAnswers] = useState<{ questionId: string; selected: number; correct: number; confidence: number }[]>([]);
  const [showExplain, setShowExplain] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("cognitiveHub_token");
    const profile = JSON.parse(localStorage.getItem("cognitiveHub_profile") || "{}");

    if (token) {
      fetch('/api/questions/start-test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          domain: profile.specialization || 'engineering',
          selectedSkills: profile.skills || [],
          selectedRole: profile.specialization || '',
          weakAreas: profile.weakAreas || [],
        }),
      })
        .then((r) => r.json())
        .then((data) => {
          if (data.questions && data.questions.length > 0) {
            setQuestions(data.questions);
          }
          if (data.session?.id) {
            setSessionId(data.session.id);
          }
        })
        .catch(() => {});
    }
  }, []);

  useEffect(() => {
    const interval = setInterval(() => setTimer((t) => Math.max(0, t - 1)), 1000);
    return () => clearInterval(interval);
  }, []);

  const formatTime = (s: number) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
  const currentQuestion = questions[currentQ];
  const progress = ((currentQ + 1) / questions.length) * 100;

  const handleSubmit = async () => {
    // Bug fix: was `if (!selected === null || !sessionId || !currentQuestion)`
    if (selected === null || !currentQuestion) return;

    const newAnswers = [...answers, { questionId: currentQuestion._id || String(currentQ), selected, correct: currentQuestion.correct, confidence }];
    setAnswers(newAnswers);

    if (currentQ < questions.length - 1) {
      setCurrentQ(currentQ + 1);
      setSelected(null);
      setConfidence(70);
      setShowExplain(false);
    } else {
      const correctCount = newAnswers.filter((a) => a.selected === a.correct).length;
      const avgConfidence = newAnswers.reduce((acc, a) => acc + a.confidence, 0) / newAnswers.length;
      const score = Math.round((correctCount / questions.length) * 70 + (avgConfidence / 100) * 30);

      localStorage.setItem("cognitiveHub_testResults", JSON.stringify({ score, answers: newAnswers, completedAt: new Date().toISOString() }));

      const token = localStorage.getItem("cognitiveHub_token");
      if (token) {
        try {
          await api.test.submit(newAnswers, questions.length);
        } catch {}
      }

      onComplete(score);
    }
  };

  const confidenceLabel = confidence > 80 ? "High Probability" : confidence > 50 ? "Moderate" : "Low Confidence";

  return (
    <div className="min-h-screen bg-background pb-24">
      <Header />
      <div className="px-5 pt-2">
        <motion.div key={currentQ} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
          <div className="flex items-center justify-between mb-1">
            <div>
              <h2 className="font-display font-bold text-xl">Adaptive Evaluation</h2>
              <p className="text-muted-foreground text-xs">Neural Architecture & Pattern Recognition</p>
            </div>
            <div className="flex items-center gap-1 bg-card rounded-full px-3 py-1">
              <div className="w-2 h-2 rounded-full bg-success" />
              <span className="font-mono text-sm font-bold">{formatTime(timer)}</span>
            </div>
          </div>

          <div className="mt-3 h-1.5 bg-secondary rounded-full overflow-hidden">
            <motion.div className="h-full gradient-primary rounded-full" animate={{ width: `${progress}%` }} />
          </div>
          <div className="flex justify-between mt-1">
            <span className="text-[10px] tracking-widest text-muted-foreground">PHASE {String(currentQ + 1).padStart(2, "0")} OF {String(questions.length).padStart(2, "0")}</span>
            <span className="text-[10px] tracking-widest text-muted-foreground">{Math.round(progress)}% COMPLETE</span>
          </div>

          <div className="mt-4 flex items-center gap-2 bg-card rounded-full px-4 py-2">
            <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            <span className="text-xs text-muted-foreground">Adjusting difficulty based on your answers</span>
          </div>

          <div className="mt-5 bg-card rounded-2xl p-5 border border-border">
            <div className="flex justify-between items-center mb-4">
              <span className="text-[10px] tracking-widest text-muted-foreground">{currentQuestion?.category}</span>
              <button className="text-xs text-muted-foreground hover:text-foreground">Skip »</button>
            </div>
            <p className="font-display text-lg font-bold leading-snug" dangerouslySetInnerHTML={{
              __html: (currentQuestion?.question || "").replace(/(\d+%)/g, '<span class="text-primary">$1</span>').replace(/\bn\b/g, '<span class="text-primary">n</span>')
            }} />
          </div>

          <div className="mt-4 space-y-3">
            {(currentQuestion?.options || []).map((opt, i) => {
              const letter = String.fromCharCode(65 + i);
              const isSelected = selected === i;
              return (
                <button
                  key={i}
                  onClick={() => setSelected(i)}
                  className={`w-full flex items-center gap-3 p-4 rounded-xl border transition-all text-left ${
                    isSelected ? "border-primary bg-primary/10 glow-purple" : "border-border bg-card hover:border-primary/40"
                  }`}
                >
                  <span className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold ${isSelected ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>
                    {letter}
                  </span>
                  <span className="text-sm">{opt}</span>
                </button>
              );
            })}
          </div>

          <div className="mt-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] tracking-widest font-bold">CONFIDENCE LEVEL</span>
              <span className="text-xs font-mono text-primary bg-primary/10 px-2 py-0.5 rounded">{confidenceLabel}</span>
            </div>
            <input
              type="range" min={0} max={100} value={confidence}
              onChange={(e) => setConfidence(Number(e.target.value))}
              className="w-full h-1 bg-secondary rounded-full appearance-none [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-primary [&::-webkit-slider-thumb]:glow-purple"
            />
            <div className="flex justify-between mt-1">
              <span className="text-[10px] text-muted-foreground">GUESSING</span>
              <span className="text-[10px] text-muted-foreground">CERTAIN</span>
            </div>
          </div>

          <button
            onClick={handleSubmit}
            disabled={selected === null}
            className="w-full mt-6 py-4 rounded-2xl gradient-cta text-primary-foreground font-display font-bold text-lg disabled:opacity-40 transition-transform hover:scale-[1.02] active:scale-[0.98]"
          >
            Submit Answer
          </button>

          <button
            onClick={() => setShowExplain(!showExplain)}
            className="w-full mt-3 py-3 rounded-2xl border border-primary/30 bg-primary/5 text-primary font-medium flex items-center justify-center gap-2"
          >
            <HelpCircle size={16} /> Explain this question
          </button>
          {showExplain && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} className="mt-3 bg-card rounded-xl p-4 border border-border">
              <p className="text-sm text-muted-foreground">{currentQuestion?.explanation || "This question tests your understanding of the AI concept."}</p>
            </motion.div>
          )}

          <div className="mt-6 flex gap-3 items-start mb-6">
            <div className="w-8 h-8 rounded-full bg-success/20 flex items-center justify-center flex-shrink-0">
              <span className="text-success text-xs">💡</span>
            </div>
            <div>
              <p className="text-[10px] tracking-widest font-bold mb-1">COGNITIVE TIP</p>
              <p className="text-xs text-muted-foreground leading-relaxed">
                The AI has detected that you favor spatial reasoning. Look for geometric patterns in the efficiency curves mentioned above.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default AdaptiveTestScreen;
