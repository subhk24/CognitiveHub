import { useState } from "react";
import { motion } from "framer-motion";
import { Zap, Mail, Lock, User, Eye, EyeOff } from "lucide-react";
import { api, saveToken, saveUser } from "@/lib/api";

interface AuthScreenProps {
  onAuthenticated: () => void;
}

const AuthScreen = ({ onAuthenticated }: AuthScreenProps) => {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async () => {
    setError("");
    if (!email || !password) {
      setError("Email and password are required");
      return;
    }
    if (mode === "register" && !name) {
      setError("Name is required");
      return;
    }
    setLoading(true);
    try {
      let result;
      if (mode === "register") {
        result = await api.auth.register(name, email, password);
      } else {
        result = await api.auth.login(email, password);
      }
      saveToken(result.token);
      saveUser(result.user);
      onAuthenticated();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Authentication failed";
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleSkip = () => {
    onAuthenticated();
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-5">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-sm"
      >
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl gradient-primary flex items-center justify-center mx-auto mb-4 glow-purple">
            <Zap size={28} className="text-primary-foreground" />
          </div>
          <h1 className="font-display text-3xl font-bold">Cognitive Hub</h1>
          <p className="text-muted-foreground text-sm mt-2">
            {mode === "login" ? "Sign in to continue your journey" : "Begin your AI proficiency path"}
          </p>
        </div>

        <div className="bg-card rounded-2xl p-6 border border-border space-y-4">
          {mode === "register" && (
            <div className="relative">
              <User size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                type="text"
                placeholder="Full Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-secondary rounded-xl pl-9 pr-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>
          )}

          <div className="relative">
            <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
              className="w-full bg-secondary rounded-xl pl-9 pr-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
            />
          </div>

          <div className="relative">
            <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type={showPassword ? "text" : "password"}
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
              className="w-full bg-secondary rounded-xl pl-9 pr-10 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
            />
            <button
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>

          {error && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-destructive text-xs text-center bg-destructive/10 rounded-lg p-2"
            >
              {error}
            </motion.p>
          )}

          <button
            onClick={handleSubmit}
            disabled={loading}
            className="w-full py-3 rounded-xl gradient-cta text-primary-foreground font-display font-bold text-sm disabled:opacity-50 transition-transform hover:scale-[1.02] active:scale-[0.98]"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mx-auto" />
            ) : mode === "login" ? (
              "Sign In"
            ) : (
              "Create Account"
            )}
          </button>
        </div>

        <div className="text-center mt-4 space-y-2">
          <button
            onClick={() => { setMode(mode === "login" ? "register" : "login"); setError(""); }}
            className="text-sm text-muted-foreground hover:text-foreground"
          >
            {mode === "login" ? "No account? Register" : "Already have an account? Sign in"}
          </button>
          <div>
            <button
              onClick={handleSkip}
              className="text-xs text-muted-foreground/60 hover:text-muted-foreground"
            >
              Continue as guest
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default AuthScreen;
