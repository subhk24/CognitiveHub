import { motion } from "framer-motion";
import { Flame, Trophy, ChevronRight, HelpCircle, Zap } from "lucide-react";
import Header from "@/components/Header";

interface GrowthScreenProps {
  onComplete: () => void;
}

const weeklyData = [
  { day: "MON", value: 60 },
  { day: "TUE", value: 75 },
  { day: "WED", value: 55 },
  { day: "THU", value: 80 },
  { day: "FRI", value: 90 },
  { day: "SAT", value: 100 },
  { day: "SUN", value: 70 },
];

const badges = [
  { name: "AI Beginner", desc: "Unlocked 4 days ago", emoji: "🔥" },
  { name: "Prompt Engineering Pro", desc: "Top 5% of users", emoji: "🧠" },
];

const tips = [
  {
    icon: <HelpCircle size={20} className="text-primary" />,
    title: "Refine Logic Paths",
    desc: "Your prompt structure is strong, but try breaking complex queries into 3 distinct logical steps for 15% better AI accuracy.",
  },
  {
    icon: <Zap size={20} className="text-primary" />,
    title: "Reduce Latency",
    desc: "Focus on concise tokens. Aim for under 50 words per initial prompt to decrease system processing time.",
  },
];

const GrowthScreen = ({ onComplete }: GrowthScreenProps) => {
  const maxVal = Math.max(...weeklyData.map((d) => d.value));

  return (
    <div className="min-h-screen bg-background pb-24">
      <Header subtitle="AI Core Pulse" />
      <div className="px-5 pt-2">
        <p className="text-[10px] tracking-widest text-primary mb-1">PERFORMANCE OVERVIEW</p>
        <h1 className="font-display text-3xl font-bold leading-tight">Your Cognitive<br />Evolution</h1>

        {/* Streak */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="mt-5">
          <div className="bg-card rounded-2xl p-4 border border-border flex items-center gap-3">
            <Flame size={28} className="text-destructive" />
            <div>
              <span className="font-display text-2xl font-bold">14</span>
              <p className="text-[10px] tracking-widest text-muted-foreground">DAY STREAK</p>
            </div>
          </div>
        </motion.div>

        {/* Weekly Chart */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="mt-4">
          <div className="bg-card rounded-2xl p-5 border border-border">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="font-display font-bold text-lg">Weekly Improvement</h3>
                <p className="text-xs text-muted-foreground">Intelligence quotient growth over 7 days</p>
              </div>
              <span className="text-xs bg-success/20 text-success px-2 py-0.5 rounded-full">+12.4%</span>
            </div>
            <div className="flex items-end gap-2 h-32">
              {weeklyData.map((d, i) => {
                const h = (d.value / maxVal) * 100;
                const isCurrent = d.day === "SAT";
                return (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1">
                    {isCurrent && (
                      <div className="bg-card border border-border rounded px-1.5 py-0.5 mb-1">
                        <p className="text-[8px] tracking-wider text-muted-foreground">CURRENT</p>
                        <p className="text-xs font-bold">1040</p>
                      </div>
                    )}
                    <motion.div
                      initial={{ height: 0 }}
                      animate={{ height: `${h}%` }}
                      transition={{ delay: 0.3 + i * 0.05 }}
                      className={`w-full rounded-md ${isCurrent ? "gradient-primary" : "bg-primary/30"}`}
                    />
                  </div>
                );
              })}
            </div>
            <div className="flex gap-2 mt-2">
              {weeklyData.map((d, i) => (
                <span key={i} className="flex-1 text-center text-[9px] text-muted-foreground">{d.day}</span>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Badges */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="mt-4">
          <div className="bg-card rounded-2xl p-5 border border-border">
            <p className="text-[10px] tracking-widest text-muted-foreground mb-3">EARNED BADGES</p>
            <div className="space-y-3">
              {badges.map((b, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-lg">{b.emoji}</div>
                  <div>
                    <p className="font-bold text-sm">{b.name}</p>
                    <p className="text-xs text-muted-foreground">{b.desc}</p>
                  </div>
                </div>
              ))}
            </div>
            <button className="mt-3 text-xs text-muted-foreground tracking-wider hover:text-foreground transition-colors">VIEW ALL ACHIEVEMENTS</button>
          </div>
        </motion.div>

        {/* Next Challenge */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="mt-4">
          <div className="gradient-primary rounded-2xl p-5 text-center">
            <Trophy size={28} className="mx-auto mb-2 text-primary-foreground" />
            <p className="text-[10px] tracking-widest text-primary-foreground/70">NEXT GOAL</p>
            <p className="font-display font-bold text-lg text-primary-foreground">Next Challenge</p>
            <p className="text-xs text-primary-foreground/70 mt-1 flex items-center justify-center gap-1">
              EARN +500 XP <ChevronRight size={14} />
            </p>
          </div>
        </motion.div>

        {/* Improvement Tips */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="mt-6">
          <h2 className="font-display text-xl font-bold">Here's how to improve your score</h2>
          <p className="text-xs text-muted-foreground mt-1 mb-4">Personalized insights based on your recent activity and synapse patterns.</p>
          <div className="space-y-3">
            {tips.map((tip, i) => (
              <div key={i} className="bg-card rounded-2xl p-4 border border-border">
                <div className="mb-2">{tip.icon}</div>
                <p className="font-display font-bold text-sm">{tip.title}</p>
                <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{tip.desc}</p>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Continue */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }} className="mt-6">
          <button onClick={onComplete} className="w-full py-4 rounded-2xl gradient-cta text-primary-foreground font-display font-bold text-lg transition-transform hover:scale-[1.02] active:scale-[0.98]">
            View Recruiter Dashboard
          </button>
        </motion.div>
      </div>
    </div>
  );
};

export default GrowthScreen;
