import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Heart, MessageCircle, Hash, Search } from "lucide-react";
import Header from "@/components/Header";
import { io, Socket } from "socket.io-client";

interface ChatMessage {
  id: string;
  user: string;
  avatar: string;
  message: string;
  timestamp: string;
  likes: number;
  topic?: string;
}

const topics = ["All", "AI Architecture", "Prompt Engineering", "AI Ethics", "ML Tips", "Study Groups", "General", "ML Fundamentals", "Healthcare AI"];

const formatTime = (dateStr: string | Date) => {
  const d = new Date(dateStr);
  const diff = Date.now() - d.getTime();
  if (diff < 60000) return "Just now";
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
  return d.toLocaleDateString();
};

const CommunityScreen = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [activeTopic, setActiveTopic] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [loading, setLoading] = useState(true);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const socketRef = useRef<Socket | null>(null);

  const normalizeMsg = (m: Record<string, unknown>): ChatMessage => ({
    id: String(m.id || m._id || Date.now()),
    user: String(m.username || m.user || 'Anonymous'),
    avatar: String(m.avatar || '⭐'),
    message: String(m.message || ''),
    timestamp: m.createdAt ? formatTime(String(m.createdAt)) : String(m.timestamp || 'Just now'),
    likes: Number(m.likes || 0),
    topic: String(m.topic || 'General'),
  });

  const loadMessages = useCallback(async () => {
    try {
      const res = await fetch('/api/community/messages');
      const data = await res.json();
      if (data.messages) {
        setMessages(data.messages.map(normalizeMsg));
      }
    } catch {}
    setLoading(false);
  }, []);

  useEffect(() => {
    loadMessages();
  }, [loadMessages]);

  useEffect(() => {
    const socket = io('/', { path: '/socket.io', transports: ['websocket', 'polling'] });
    socketRef.current = socket;

    socket.on('newCommunityMessage', (msg: Record<string, unknown>) => {
      setMessages((prev) => [...prev, normalizeMsg(msg)]);
    });

    return () => { socket.disconnect(); };
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const filtered = messages.filter((m) => {
    const topicMatch = activeTopic === "All" || m.topic === activeTopic;
    const searchMatch = !searchQuery || m.message.toLowerCase().includes(searchQuery.toLowerCase()) || m.user.toLowerCase().includes(searchQuery.toLowerCase());
    return topicMatch && searchMatch;
  });

  const handleSend = async () => {
    if (!newMessage.trim()) return;
    const token = localStorage.getItem("cognitiveHub_token");
    const topic = activeTopic === "All" ? "General" : activeTopic;

    const optimistic: ChatMessage = {
      id: `opt_${Date.now()}`,
      user: "You",
      avatar: "⭐",
      message: newMessage.trim(),
      timestamp: "Just now",
      likes: 0,
      topic,
    };

    setMessages((prev) => [...prev, optimistic]);
    setNewMessage("");

    if (token) {
      try {
        await fetch('/api/community/messages', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
          body: JSON.stringify({ message: newMessage.trim(), topic, avatar: '⭐' }),
        });
      } catch {}
    }
  };

  const handleLike = async (id: string) => {
    setMessages((prev) => prev.map((m) => m.id === id ? { ...m, likes: m.likes + 1 } : m));
    const token = localStorage.getItem("cognitiveHub_token");
    if (token) {
      try {
        await fetch(`/api/community/messages/${id}/like`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
        });
      } catch {}
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24 flex flex-col">
      <Header subtitle="COMMUNITY" />
      <div className="px-5 pt-2 flex-1 flex flex-col">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-[10px] tracking-widest text-primary mb-1">NEURAL NETWORK</p>
              <h1 className="font-display text-2xl font-bold">Community</h1>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => setShowSearch(!showSearch)} className="w-8 h-8 rounded-lg bg-card border border-border flex items-center justify-center">
                <Search size={14} className="text-muted-foreground" />
              </button>
              <div className="flex items-center gap-1 bg-success/10 px-2 py-1 rounded-full">
                <div className="w-1.5 h-1.5 rounded-full bg-success animate-pulse" />
                <span className="text-[10px] text-success font-medium">247 online</span>
              </div>
            </div>
          </div>
        </motion.div>

        <AnimatePresence>
          {showSearch && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="mt-3">
              <input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search messages..."
                className="w-full bg-card border border-border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-primary"
              />
            </motion.div>
          )}
        </AnimatePresence>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="mt-4">
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {topics.map((t) => (
              <button
                key={t}
                onClick={() => setActiveTopic(t)}
                className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                  activeTopic === t ? "border-primary bg-primary/20 text-primary" : "border-border bg-card text-muted-foreground"
                }`}
              >
                <Hash size={10} className="inline mr-1" />{t}
              </button>
            ))}
          </div>
        </motion.div>

        <div className="mt-4 flex-1 space-y-3 overflow-y-auto">
          {loading && (
            <div className="flex items-center justify-center py-12">
              <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
            </div>
          )}
          {!loading && filtered.length === 0 && (
            <div className="text-center py-12 text-muted-foreground text-sm">
              No messages yet. Be the first to share something!
            </div>
          )}
          {filtered.map((msg, i) => {
            const isYou = msg.user === "You";
            return (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.03 }}
                className={`bg-card rounded-2xl p-4 border ${isYou ? "border-primary/30 bg-primary/5" : "border-border"}`}
              >
                <div className="flex items-start gap-3">
                  <span className="text-xl flex-shrink-0">{msg.avatar}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`font-bold text-sm ${isYou ? "text-primary" : ""}`}>{msg.user}</span>
                      <span className="text-[10px] text-muted-foreground">{msg.timestamp}</span>
                      {msg.topic && (
                        <span className="text-[9px] bg-muted px-1.5 py-0.5 rounded text-muted-foreground">#{msg.topic}</span>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mt-1 leading-relaxed">{msg.message}</p>
                    <div className="flex items-center gap-4 mt-2">
                      <button
                        onClick={() => handleLike(msg.id)}
                        className="flex items-center gap-1 text-[10px] text-muted-foreground hover:text-destructive transition-colors"
                      >
                        <Heart size={12} className={msg.likes > 0 ? "fill-destructive text-destructive" : ""} /> {msg.likes}
                      </button>
                      <button className="flex items-center gap-1 text-[10px] text-muted-foreground hover:text-primary transition-colors">
                        <MessageCircle size={12} /> Reply
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
          <div ref={chatEndRef} />
        </div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="sticky bottom-20 mt-3 pb-2">
          <div className="flex gap-2">
            <input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
              placeholder="Share your thoughts..."
              className="flex-1 bg-card border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-primary"
            />
            <button
              onClick={handleSend}
              disabled={!newMessage.trim()}
              className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center disabled:opacity-40 transition-transform hover:scale-105 active:scale-95"
            >
              <Send size={18} className="text-primary-foreground" />
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default CommunityScreen;
