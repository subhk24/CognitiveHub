import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle, Circle, Flame, Users, Zap, Clock, ChevronRight } from "lucide-react";
import Header from "@/components/Header";
import { dailyTasks, getCompletedTasks, completeTask, getUserXP } from "@/data/mockData";

const DailyTasksScreen = () => {
  const [completed, setCompleted] = useState<string[]>(getCompletedTasks());
  const [xp, setXp] = useState(getUserXP());
  const [celebrateId, setCelebrateId] = useState<string | null>(null);

  const totalTasks = dailyTasks.length;
  const completedCount = completed.length;
  const progress = (completedCount / totalTasks) * 100;

  const handleComplete = (taskId: string) => {
    if (completed.includes(taskId)) return;
    const updated = completeTask(taskId);
    setCompleted(updated);
    setXp(getUserXP());
    setCelebrateId(taskId);
    setTimeout(() => setCelebrateId(null), 1500);
  };

  const difficultyColor = (d: string) => {
    switch (d) {
      case "easy": return "text-success bg-success/10 border-success/30";
      case "medium": return "text-warning bg-warning/10 border-warning/30";
      case "hard": return "text-destructive bg-destructive/10 border-destructive/30";
      default: return "";
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <Header subtitle="ACTIVE CORE" />
      <div className="px-5 pt-2">
        {/* Summary Header */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <p className="text-[10px] tracking-widest text-primary mb-1">DAILY MISSIONS</p>
          <h1 className="font-display text-3xl font-bold leading-tight">Today's Tasks</h1>
          <p className="text-sm text-muted-foreground mt-1">Complete tasks to earn XP and climb the leaderboard</p>
        </motion.div>

        {/* Stats Row */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="grid grid-cols-3 gap-3 mt-5">
          <div className="bg-card rounded-xl p-3 border border-border text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Clock size={14} className="text-primary" />
            </div>
            <p className="font-display font-bold text-xl">{totalTasks}</p>
            <p className="text-[9px] tracking-widest text-muted-foreground">TOTAL TASKS</p>
          </div>
          <div className="bg-card rounded-xl p-3 border border-border text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <CheckCircle size={14} className="text-success" />
            </div>
            <p className="font-display font-bold text-xl">{completedCount}</p>
            <p className="text-[9px] tracking-widest text-muted-foreground">COMPLETED</p>
          </div>
          <div className="bg-card rounded-xl p-3 border border-border text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Zap size={14} className="text-warning" />
            </div>
            <p className="font-display font-bold text-xl">{xp}</p>
            <p className="text-[9px] tracking-widest text-muted-foreground">XP EARNED</p>
          </div>
        </motion.div>

        {/* Progress Bar */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="mt-4">
          <div className="flex justify-between mb-1">
            <span className="text-xs text-muted-foreground">Daily Progress</span>
            <span className="text-xs font-bold text-primary">{Math.round(progress)}%</span>
          </div>
          <div className="h-2 bg-secondary rounded-full overflow-hidden">
            <motion.div
              className="h-full gradient-primary rounded-full"
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>
        </motion.div>

        {/* Task List */}
        <div className="mt-6 space-y-3">
          {dailyTasks.map((task, i) => {
            const isDone = completed.includes(task.id);
            const isCelebrating = celebrateId === task.id;
            return (
              <motion.div
                key={task.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 + i * 0.05 }}
                className={`bg-card rounded-2xl p-4 border transition-all ${
                  isDone ? "border-success/30 bg-success/5" : "border-border"
                } ${isCelebrating ? "glow-purple" : ""}`}
              >
                <div className="flex items-start gap-3">
                  {/* Checkbox */}
                  <button onClick={() => handleComplete(task.id)} className="mt-0.5 flex-shrink-0">
                    <AnimatePresence mode="wait">
                      {isDone ? (
                        <motion.div key="done" initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }}>
                          <CheckCircle size={22} className="text-success" />
                        </motion.div>
                      ) : (
                        <motion.div key="todo" initial={{ scale: 0.8 }} animate={{ scale: 1 }}>
                          <Circle size={22} className="text-muted-foreground hover:text-primary transition-colors" />
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </button>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <h3 className={`font-display font-bold text-sm ${isDone ? "line-through text-muted-foreground" : ""}`}>
                        {task.title}
                      </h3>
                      <span className={`text-[9px] px-2 py-0.5 rounded-full border ${difficultyColor(task.difficulty)}`}>
                        {task.difficulty.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed">{task.description}</p>

                    {/* Meta row */}
                    <div className="flex items-center gap-4 mt-2">
                      <span className="flex items-center gap-1 text-[10px] text-primary">
                        <Zap size={10} /> +{task.xp} XP
                      </span>
                      <span className="flex items-center gap-1 text-[10px] text-muted-foreground">
                        <Users size={10} /> {task.totalCompletions.toLocaleString()} completed
                      </span>
                      <span className="text-[10px] text-muted-foreground bg-muted px-2 py-0.5 rounded">
                        {task.category}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Celebration animation */}
                {isCelebrating && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="mt-2 text-center"
                  >
                    <span className="text-xs font-bold text-success">🎉 +{task.xp} XP earned!</span>
                  </motion.div>
                )}
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default DailyTasksScreen;
