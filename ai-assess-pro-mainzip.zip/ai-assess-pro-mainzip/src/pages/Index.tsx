import { useState, useEffect } from "react";
import BottomNav from "@/components/BottomNav";
import AuthScreen from "@/screens/AuthScreen";
import OnboardingScreen from "@/screens/OnboardingScreen";
import AdaptiveTestScreen from "@/screens/AdaptiveTestScreen";
import InterviewScreen from "@/screens/InterviewScreen";
import TransparencyScreen from "@/screens/TransparencyScreen";
import GrowthScreen from "@/screens/GrowthScreen";
import RecruiterScreen from "@/screens/RecruiterScreen";
import DailyTasksScreen from "@/screens/DailyTasksScreen";
import LeaderboardScreen from "@/screens/LeaderboardScreen";
import CommunityScreen from "@/screens/CommunityScreen";
import { getUser } from "@/lib/api";

type Screen = "auth" | "onboarding" | "test" | "interview" | "transparency" | "growth" | "recruiter" | "tasks" | "leaderboard" | "community";

const Index = () => {
  const [screen, setScreen] = useState<Screen>("auth");
  const [score, setScore] = useState(78);
  const [activeTab, setActiveTab] = useState("nexus");

  useEffect(() => {
    const token = localStorage.getItem("cognitiveHub_token");
    const user = getUser();
    if (token && user) {
      setScreen("onboarding");
    }
  }, []);

  const navigateTab = (tab: string) => {
    setActiveTab(tab);
    const map: Record<string, Screen> = {
      nexus: "onboarding",
      vault: "test",
      tasks: "tasks",
      ranks: "leaderboard",
      chat: "community",
      synapse: "transparency",
      profile: "recruiter",
    };
    if (map[tab]) setScreen(map[tab]);
  };

  if (screen === "auth") {
    return <AuthScreen onAuthenticated={() => setScreen("onboarding")} />;
  }

  return (
    <div className="max-w-md mx-auto min-h-screen relative">
      {screen === "onboarding" && (
        <OnboardingScreen onComplete={() => { setScreen("test"); setActiveTab("vault"); }} />
      )}
      {screen === "test" && (
        <AdaptiveTestScreen onComplete={(s) => { setScore(s); setScreen("interview"); setActiveTab("synapse"); }} />
      )}
      {screen === "interview" && (
        <InterviewScreen onComplete={() => { setScreen("transparency"); setActiveTab("synapse"); }} />
      )}
      {screen === "transparency" && (
        <TransparencyScreen score={score} onComplete={() => { setScreen("growth"); setActiveTab("synapse"); }} />
      )}
      {screen === "growth" && (
        <GrowthScreen onComplete={() => { setScreen("recruiter"); setActiveTab("profile"); }} />
      )}
      {screen === "recruiter" && <RecruiterScreen />}
      {screen === "tasks" && <DailyTasksScreen />}
      {screen === "leaderboard" && <LeaderboardScreen />}
      {screen === "community" && <CommunityScreen />}
      <BottomNav active={activeTab} onNavigate={navigateTab} />
    </div>
  );
};

export default Index;
