# Cognitive Hub — Full Stack App

## Overview
A gamified AI-recruitment and proficiency-tracking platform with:
- React + TypeScript + Vite + Tailwind CSS frontend (port 5000)
- Node.js + Express + TypeScript backend (port 3001)
- MongoDB + in-memory fallback storage
- JWT authentication (register/login)
- Adaptive testing with dynamic question generation
- Interview microphone transcript saving
- Leaderboard, community, daily tasks

## Architecture

### Frontend (root directory)
- **Framework**: React 18 + TypeScript + Vite
- **Styling**: Tailwind CSS + shadcn/ui
- **Animations**: Framer Motion
- **State**: React useState + localStorage
- **API client**: `src/lib/api.ts` — proxies all `/api/*` calls to backend on port 3001

### Backend (`/backend` directory)
- **Framework**: Express + TypeScript
- **Database**: MongoDB via Mongoose (falls back to in-memory store when MongoDB is unavailable)
- **Auth**: JWT (bcryptjs password hashing)
- **Port**: 3001

## Workflows
- **Start application** — `npm run dev` → Vite on port 5000 (webview)
- **Backend API** — `cd backend && npx tsc && node dist/index.js` → Express on port 3001 (console)

## Key Files
- `src/pages/Index.tsx` — Main app router with auth flow
- `src/screens/AuthScreen.tsx` — Login/register screen
- `src/screens/AdaptiveTestScreen.tsx` — Adaptive quiz (syncs results to backend)
- `src/screens/InterviewScreen.tsx` — AI interview with microphone transcript saving
- `src/lib/api.ts` — Frontend API client
- `backend/src/index.ts` — Express server entry point
- `backend/src/routes/auth.ts` — JWT auth routes
- `backend/src/routes/test.ts` — Test submission & leaderboard routes
- `backend/src/routes/interview.ts` — Interview & transcript routes
- `backend/src/routes/questions.ts` — Question fetching & generation routes
- `backend/src/store/memoryStore.ts` — In-memory fallback store (no MongoDB needed)
- `backend/.env` — Backend environment variables (PORT, MONGODB_URI, JWT_SECRET)
- `vite.config.ts` — Vite config with `/api` proxy to backend

## Environment Variables (backend/.env)
```
PORT=3001
MONGODB_URI=mongodb://localhost:27017/cognitivehub
JWT_SECRET=cognitive_hub_jwt_secret_key_2024_secure
JWT_EXPIRES_IN=7d
NODE_ENV=development
```
To use MongoDB Atlas, update `MONGODB_URI` in `backend/.env`.

## API Endpoints
- `GET  /api/health` — Health check
- `POST /api/auth/register` — Register user
- `POST /api/auth/login` — Login
- `GET  /api/auth/me` — Get current user (JWT)
- `PUT  /api/auth/profile` — Update profile (JWT)
- `GET  /api/questions` — List questions (JWT)
- `GET  /api/questions/generate` — Generate adaptive questions (JWT)
- `POST /api/test/submit` — Submit test answers (JWT)
- `GET  /api/test/leaderboard` — Leaderboard
- `POST /api/interview/start` — Start interview session (JWT)
- `POST /api/interview/:id/transcript` — Save transcript entry (JWT)
- `POST /api/interview/:id/complete` — Mark interview complete (JWT)
- `POST /api/interview/:id/human-review` — Request human review (JWT)

## Running Locally
```bash
# Install all deps
npm install
cd backend && npm install

# Run both services at once
npm run dev:all

# Or separately:
npm run dev              # Frontend on :5000
npm run dev:backend      # Backend on :3001
```
